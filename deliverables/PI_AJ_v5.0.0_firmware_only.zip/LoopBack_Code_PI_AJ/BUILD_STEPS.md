# Build PI-AJ v5 step by step (zip → BOOT.BIN → SD card)

PI-AJ v5 replaces the SMI-PI anti-jam filter. Everything else in this project
(AD9361 setup, gnss_passthrough, DMA, console, gain loop, reports) is the
v4.5.0 code, unchanged. What is new: `Source/HDL/pi_aj` (the filter, Verilog),
`Source/IP/pi_aj` (its IP packaging), `Tests/pi_aj` (its RTL self-test) and the
firmware driver `gnss_piaj.c/.h`. **Vitis HLS is no longer needed.**

Type every command below in a Linux terminal (Ubuntu 22.04 or 20.04) on the
PC with the Xilinx tools, the same PC and flow as the v4.x builds. Wait for each
step's check line before going to the next step.

---

## 0. Once per PC

```bash
# tools check (Vivado and Vitis 2023.2; Vitis HLS is not needed any more)
ls /tools/Xilinx/Vivado/2023.2/settings64.sh /tools/Xilinx/Vitis/2023.2/settings64.sh

# build helpers + the RTL self-test (iverilog, numpy)
sudo apt update
sudo apt install -y unzip make gcc g++ git iverilog python3-numpy
```

If the tools are in `/opt/Xilinx`, use that path everywhere below.

---

## 1. Unzip into a NEW folder

```bash
mkdir -p ~/pi_aj_v5
cd ~/pi_aj_v5
unzip ~/Downloads/LoopBack_Code_PI_AJ_v5.0.0.zip
cd LoopBack_Code_PI_AJ
chmod +x Automation/Linux/*.sh Automation/Linux/steps/*.sh Tests/pi_aj/selftest.sh
```

Do not unzip over the SMI-PI folder.

---

## 2. Load the tools (every new terminal)

```bash
source /tools/Xilinx/Vivado/2023.2/settings64.sh
source /tools/Xilinx/Vitis/2023.2/settings64.sh
vivado -version | head -1          # must say v2023.2
which xsct bootgen iverilog        # all three must be found
```

---

## 3. Build, one step at a time

Run every step from the `LoopBack_Code_PI_AJ` folder.

### Step 1: copy the ADI library (seconds)

```bash
./Automation/Linux/steps/01_vendor.sh
```
Check: `STEP 1 vendor: PASS`

### Step 2: package the ADI library IP (5–10 min)

```bash
./Automation/Linux/steps/02_libip.sh
```
Check: `STEP 2 libip: PASS (11 library logs ...)`

### Step 3: PI-AJ v5 core: RTL self-test + IP (2–4 min)

```bash
./Automation/Linux/steps/03_piaj.sh
```
Check, both lines:
```
PI_AJ_RTLSIM: RX1 C/N0 ... -> TX1 C/N0 ~46 dB-Hz, RMS suppression ~61 dB, samples 100000 in / 100000 out, late 0, overrun 0
PI_AJ_RTLSIM: PASS
PI_AJ_IP: PASS - .../Build/ip_repo/pi_aj/component.xml (antsdr:gnss:pi_aj:5.0)
```
The self-test runs the exact Verilog of this build on a CW jammer at
1575.40 MHz (J/N 61 dB). Without iverilog it prints `skipped` and only the IP is packaged.

### Step 4: package gnss_passthrough (1–2 min, unchanged)

```bash
./Automation/Linux/steps/04_ip.sh
```
Check: `IP_PACKAGE_OK`

### Step 5: create the Vivado project (2–5 min)

```bash
./Automation/Linux/steps/05_project.sh
```
Check: `CREATE_RESULT: PASS`, and in the log:
```bash
grep "PI-AJ v5 IP resolved" Build/Logs/project.log
```
must print `GNSS-CRPA: PI-AJ v5 IP resolved in catalog: antsdr:gnss:pi_aj:5.0`.

### Step 6: synthesis, implementation, bitstream (20–60 min)

```bash
./Automation/Linux/steps/06_build.sh
```
Check:
```
BUILD_TIMING: MET
BUILD_RESULT: PASS
Build/Output/system_top.bit   Build/Output/system.xsa   (listed)
```
If it says `BUILD_TIMING: VIOLATED`, run step 10 to see where, then send me
`./Automation/Linux/steps/10_report.sh --paths` output (paths inside
`pi_aj_0` are mine to fix; paths on `rx_clk` are the AD9361 interface: see the v4.x note in
`README_VIVADO_2023.2.md`).

### Step 7: the application ELF (2–5 min)

Choose ONE:

```bash
# (a) bench / console build: TX1 silent at power-on, you type gnss_tx=1
./Automation/Linux/steps/07_sw.sh

# (b) unattended SD-card build: TX1 starts BY ITSELF at power-on (70 dB attenuation)
#     CONDUCTED, ATTENUATED COAX ONLY. Read SD_Image/README_SD_CARD.md first.
./Automation/Linux/steps/07_sw.sh --defines GNSS_DEPLOY_AUTO_TX
```
Check: `SW_RESULT: PASS`

### Step 8: the FSBL (1–3 min)

```bash
./Automation/Linux/steps/08_fsbl.sh
```
Check: `FSBL_RESULT: PASS`

### Step 9: BOOT.BIN (seconds)

```bash
./Automation/Linux/steps/09_boot.sh
```
Check: `Build/Output/BOOT.BIN` is listed, then:
```bash
ls -l Build/Output/BOOT.BIN
sha256sum Build/Output/BOOT.BIN
```

### Step 10: one-page report (optional)

```bash
./Automation/Linux/steps/10_report.sh
```

---

## 4. All in one go (same result as steps 1–9)

```bash
./Automation/Linux/build_all.sh --jobs 8                                  # bench build
./Automation/Linux/build_all.sh --jobs 8 --defines GNSS_DEPLOY_AUTO_TX    # SD-card build
```

Only the firmware changed? Then:
```bash
./Automation/Linux/build_all.sh --from sw --to boot
```

---

## 5. SD card

1. Format the card as **FAT32**.
2. Copy **`Build/Output/BOOT.BIN`** to the **root** of the card (not `SD_Image/BOOT.BIN`, that is an old SMI-PI image).
3. BOOT switch to **SD**, card in, RF connected as before (RX1, RX2 antennas; TX1 to the receiver through attenuation).
4. Power on. The console (PuTTY, 115200 8N1) must show, among the other lines:

```
gnss_pt: present at 0x43c00000, version 4.5
ANTI-JAM (PI-AJ v5.0.0): ON, bypassed until a jammer appears.
  PI-AJ v5 filters up to 33.3 MS/s: use gnss_band=0 (L1, 30.72 MS/s) or gnss_band=5 <LO> <rate>.
```
Then type `gnss_piaj?`. It must print `--- PI-AJ v5 @ 0x43d00000 ...` and
`max 33.33 MS/s at 100 MHz`. If it prints `pi_aj_0 not found`, the card holds
an old BOOT.BIN.

---

## 6. If a step fails

```bash
tail -50 Build/Logs/<stage>.log     # stage = piaj_sim, piaj, ip, project, build, sw, fsbl, boot
./Automation/Linux/steps/10_report.sh
```
Send me the failing step, the last 50 lines of its log and the `10_report.sh` output.
