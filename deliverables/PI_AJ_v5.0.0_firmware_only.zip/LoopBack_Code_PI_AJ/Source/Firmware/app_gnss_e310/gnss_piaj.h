/******************************************************************************
 *  gnss_piaj.h  --  driver for the PI-AJ v5 anti-jam core (pi_aj_0)
 *
 *  PI-AJ v5 replaces the SMI-PI HLS filter smi_pi_0 in the same place of the
 *  block design (between smi_fifo_in and smi_fifo_out, on sys_cpu_clk):
 *
 *    RX1,RX2 -> CW notch (self-tuned) -> I/Q-image notch -> widely-linear
 *               space-time POWER INVERSION (2 ch x 5 taps + conjugate taps,
 *               RX1 centre tap fixed to 1, NLMS every sample) -> x 2^shift -> TX1
 *
 *  The core adapts its own weights in the FPGA; the ARM only switches it in
 *  (jammer detected) or out (bypass, TX1 = RX1), sets the output make-up
 *  shift and reads the status for the reports.
 *
 *  The register map MUST stay in step with Source/HDL/pi_aj/pi_aj_axil_regs.v.
 *****************************************************************************/
#ifndef GNSS_PIAJ_H_
#define GNSS_PIAJ_H_

#include <stdint.h>
#include "app_config.h"

#ifdef XILINX_PLATFORM
#include <xparameters.h>
#endif

#if defined(XPAR_PI_AJ_0_BASEADDR)
#define GNSS_PIAJ_BASEADDR   XPAR_PI_AJ_0_BASEADDR
#elif defined(XPAR_PI_AJ_0_S_AXI_BASEADDR)
#define GNSS_PIAJ_BASEADDR   XPAR_PI_AJ_0_S_AXI_BASEADDR
#elif defined(XPAR_PI_AJ_BASEADDR)
#define GNSS_PIAJ_BASEADDR   XPAR_PI_AJ_BASEADDR
#else
#warning "pi_aj_0 base address not found in xparameters.h; using the project-assigned 0x43D00000 (Source/BlockDesign/system_bd.tcl). Verify it against the XSA."
#define GNSS_PIAJ_BASEADDR   0x43D00000U
#endif

/* the clock pi_aj_0 runs on: sys_cpu_clk = PS7 FCLK_CLK0 */
#define GNSS_PIAJ_CLK_HZ     100000000.0

/* ---- registers -------------------------------------------------------- */
#define PIAJ_REG_ID        0x00U   /* 0x50494A35 "PIJ5"                      */
#define PIAJ_REG_VERSION   0x04U
#define PIAJ_REG_CONTROL   0x08U
#define PIAJ_REG_ADAPT     0x0CU   /* [3:0] mu, [11:8] rho, [15:12] r, [19:16] a, [24:20] shift */
#define PIAJ_REG_LEVELS    0x10U
#define PIAJ_REG_WSEL      0x14U
#define PIAJ_REG_CMD       0x18U   /* write 1: zero weights, re-acquire notches */
#define PIAJ_REG_STATUS    0x20U
#define PIAJ_REG_P_RX1     0x24U   /* powers: ADC LSB^2 x 256               */
#define PIAJ_REG_P_RX2     0x28U
#define PIAJ_REG_P_NOTCH   0x2CU
#define PIAJ_REG_P_OUT     0x30U   /* power inversion output, before the shift */
#define PIAJ_REG_NOTCH1_A  0x34U   /* {im, re} Q1.14                         */
#define PIAJ_REG_NOTCH2_A  0x38U
#define PIAJ_REG_CLIPCNT   0x3CU
#define PIAJ_REG_W_RE      0x40U   /* weight[WSEL], Q3.28                    */
#define PIAJ_REG_W_IM      0x44U
#define PIAJ_REG_SAMPLES   0x48U
#define PIAJ_REG_CAPS      0x4CU   /* {clocks/sample, lanes, taps, weights}  */

#define PIAJ_ID            0x50494A35U

/* CONTROL */
#define PIAJ_CORE_EN       (1U << 0)   /* 0: TX1 = RX1 (bypass)             */
#define PIAJ_NOTCH_EN      (1U << 1)
#define PIAJ_NOTCH2_EN     (1U << 2)
#define PIAJ_IMAGE_EN      (1U << 3)
#define PIAJ_PI_EN         (1U << 4)
#define PIAJ_AGC_EN        (1U << 5)   /* off here: the firmware sets the shift */
#define PIAJ_DCBLK_EN      (1U << 6)
#define PIAJ_BLANK_EN      (1U << 7)
#define PIAJ_FREEZE        (1U << 8)
#define PIAJ_NOTCH_FORCE   (1U << 9)
#define PIAJ_AUTO_MU       (1U << 10)
#define PIAJ_CTRL_RUN      (PIAJ_CORE_EN | PIAJ_NOTCH_EN | PIAJ_IMAGE_EN | PIAJ_PI_EN | PIAJ_AUTO_MU)

/* STATUS */
#define PIAJ_ST_NOTCH1     (1U << 0)
#define PIAJ_ST_IMAGE      (1U << 1)
#define PIAJ_ST_NOTCH2     (1U << 2)
#define PIAJ_ST_OVERLOAD   (1U << 3)
#define PIAJ_ST_LATE       (1U << 4)
#define PIAJ_ST_OVERRUN    (1U << 5)

#define PIAJ_ADAPT_DEFAULT 0x0008C600U   /* mu 0 (+1 while a CW is notched), rho 6, r 12, a 8 */
#define PIAJ_MAX_SHIFT     15

typedef struct {
    uint32_t status, control, caps, clipcnt, samples;
    double   p_rx1, p_rx2, p_notch, p_out;   /* ADC LSB^2                       */
    double   supp_db;                         /* 10 log10(P_RX1 / P_OUT)         */
    double   notch1_hz, notch2_hz;            /* jammer line(s) re the LO        */
    double   wn2;                             /* sum |w|^2 of all weights        */
    double   wc_re, wc_im;                    /* RX2 centre-tap weight           */
    int      nw;                              /* number of weights (CAPS[7:0])   */
} gnss_piaj_state_t;

uint32_t gnss_piaj_read(uint32_t off);
void     gnss_piaj_write(uint32_t off, uint32_t v);
int      gnss_piaj_present(void);             /* 1 = the bitstream has pi_aj_0  */
double   gnss_piaj_max_fs(void);              /* highest sample rate [S/s]      */

void     gnss_piaj_bypass(void);              /* TX1 = RX1                      */
void     gnss_piaj_restart(void);             /* weights 0, notches re-acquire  */
void     gnss_piaj_run(int shift);            /* filter in, TX1 x 2^shift       */
void     gnss_piaj_set_shift(int shift);
void     gnss_piaj_freeze(int on);
void     gnss_piaj_set_mu(int mu);            /* PI step 2^-mu, 0..15           */
/* notch width ~ fs 2^-rho / pi: rho 6 up to 20 MS/s (~90 kHz at 18 MS/s),
 * 7 above (~76 kHz at 30.72 MS/s) */
void     gnss_piaj_set_rho_for_fs(double fs_hz);
int      gnss_piaj_get_mu(void);
int      gnss_piaj_running(void);

/* with_weights = 1 also reads the 19 weights (about 50 us) */
void     gnss_piaj_get(gnss_piaj_state_t *s, double fs_hz, int with_weights);
void     gnss_piaj_print(double fs_hz);       /* gnss_piaj?                     */

#endif
