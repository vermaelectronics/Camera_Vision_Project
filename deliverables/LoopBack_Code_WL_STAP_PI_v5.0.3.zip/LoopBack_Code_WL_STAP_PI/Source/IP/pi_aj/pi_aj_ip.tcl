# ============================================================================
#  pi_aj_ip.tcl
#  Packages the WL-STAP-PI v5 anti-jam core (Source/HDL/pi_aj/*.v, top pi_aj_axis)
#  as a Vivado IP. It replaces the SMI-PI Vitis HLS IP (smi_pi_0) in the block
#  design, with the same two AXI-Stream ports, plus its own AXI4-Lite slave.
#
#  Self-contained (standard IP-packager commands only), like
#  Source/IP/gnss_passthrough/gnss_passthrough_ip.tcl.
#
#  INVOCATION
#    vivado -mode batch -source pi_aj_ip.tcl -tclargs <src> <out>
#      <src> absolute path to <project>/Source
#      <out> absolute path to the IP repository to write into
#
#  OUTPUT
#    <out>/pi_aj/component.xml        VLNV antsdr:gnss:pi_aj:5.0
#
#  INTERFACES
#    aclk / aresetn     sys_cpu_clk (100 MHz) / sys_cpu_resetn; clocks ALL of
#                       s_axi, s_axis_x and m_axis_y (one clock domain)
#    s_axis_x           64-bit {rx2_q, rx2_i, rx1_q, rx1_i}   (from smi_fifo_in)
#    m_axis_y           32-bit {y_q, y_i}                     (to smi_fifo_out)
#    s_axi              AXI4-Lite registers, 4 kB aperture (0x43D0_0000 in the BD)
# ============================================================================

if {$argc < 2} {
  puts "ERROR: expected 2 arguments: <source_dir> <ip_repo_dir>"
  exit 2
}

set src_dir     [file normalize [lindex $argv 0]]
set ip_repo_dir [file normalize [lindex $argv 1]]
set ip_name     "pi_aj"
set top_name    "pi_aj_axis"
set ip_dir      [file join $ip_repo_dir $ip_name]
set rtl_dir     [file join $src_dir "HDL" "pi_aj"]

set rtl_files {}
foreach f {pi_aj_frontend.v pi_aj_notch.v pi_aj_wlpi.v pi_aj_outagc.v
           pi_aj_cdc_bus.v pi_aj_axil_regs.v pi_aj_top.v pi_aj_axis.v} {
  set p [file join $rtl_dir $f]
  if {![file exists $p]} {
    puts "ERROR: required source not found: $p"
    exit 2
  }
  lappend rtl_files $p
}

file delete -force $ip_dir
file mkdir $ip_dir

create_project -force ${ip_name}_pkg [file join $ip_dir ".pkg_project"] -part xc7z020clg400-2
set_property target_language Verilog [current_project]
add_files -norecurse $rtl_files
set_property top $top_name [current_fileset]
update_compile_order -fileset sources_1

ipx::package_project -root_dir $ip_dir -vendor antsdr -library gnss \
                     -taxonomy /UserIP -import_files -force

set core [ipx::current_core]
set_property name                $ip_name                                 $core
set_property version             5.0                                      $core
set_property display_name        "WL-STAP-PI v5 anti-jam (notch + widely-linear space-time power inversion)" $core
set_property description         "2-element GNSS anti-jam: adaptive CW notches + widely-linear space-time power inversion (NLMS, every sample). Drop-in for smi_pi_0." $core
set_property vendor_display_name "ANTSDR GNSS CRPA project"               $core
set_property company_url         "https://github.com/MicroPhase"          $core

proc ensure_bus_if {core name vlnv} {
  if {[llength [ipx::get_bus_interfaces $name -of_objects $core]] == 0} {
    ipx::infer_bus_interface $name $vlnv $core
  }
  return [ipx::get_bus_interfaces $name -of_objects $core]
}
proc set_bus_param {bif name value} {
  if {[llength [ipx::get_bus_parameters $name -of_objects $bif]] == 0} {
    ipx::add_bus_parameter $name $bif
  }
  set_property value $value [ipx::get_bus_parameters $name -of_objects $bif]
}
proc add_axis_if {core name mode sigs} {
  foreach bif [ipx::get_bus_interfaces $name -of_objects $core] {
    ipx::remove_bus_interface $name $core
  }
  set bif [ipx::add_bus_interface $name $core]
  set_property abstraction_type_vlnv xilinx.com:interface:axis_rtl:1.0 $bif
  set_property bus_type_vlnv         xilinx.com:interface:axis:1.0     $bif
  set_property interface_mode        $mode                             $bif
  foreach sig $sigs {
    set pm [ipx::add_port_map $sig $bif]
    set_property physical_name "${name}_[string tolower $sig]" $pm
  }
  return $bif
}

# AXI-Stream: TDATA/TVALID/TREADY, like the SMI-PI HLS ports
add_axis_if $core s_axis_x slave  {TDATA TVALID TREADY}
add_axis_if $core m_axis_y master {TDATA TVALID TREADY}

# One clock for everything. ad_cpu_interconnect finds it through
# ASSOCIATED_BUSIF =~ s_axi:* (adi_board.tcl), so s_axi must come first.
set clk_if [ensure_bus_if $core aclk    xilinx.com:signal:clock_rtl:1.0]
set rst_if [ensure_bus_if $core aresetn xilinx.com:signal:reset_rtl:1.0]
set_bus_param $clk_if ASSOCIATED_BUSIF "s_axi:s_axis_x:m_axis_y"
set_bus_param $clk_if ASSOCIATED_RESET aresetn
set_bus_param $rst_if POLARITY         ACTIVE_LOW

# Memory map: 4 kB aperture; the base address is assigned by the block design.
if {[llength [ipx::get_memory_maps s_axi -of_objects $core]] == 0} {
  ipx::add_memory_map s_axi $core
}
set mmap [ipx::get_memory_maps s_axi -of_objects $core]
set_property slave_memory_map_ref s_axi [ipx::get_bus_interfaces s_axi -of_objects $core]
foreach b [ipx::get_address_blocks -of_objects $mmap] { ipx::remove_address_block [get_property name $b] $mmap }
ipx::add_address_block axi_lite $mmap
set ablk [ipx::get_address_blocks axi_lite -of_objects $mmap]
set_property base_address 0    $ablk
set_property range        4096 $ablk
set_property width        32   $ablk
set_property usage        register $ablk

ipx::create_xgui_files $core
ipx::update_checksums  $core
ipx::check_integrity   $core
ipx::save_core         $core

# ---- self-checks ------------------------------------------------------------
foreach n {s_axi s_axis_x m_axis_y aclk aresetn} {
  if {[llength [ipx::get_bus_interfaces $n -of_objects $core]] != 1} {
    puts "PI_AJ_IP: FAIL - bus interface $n missing (check the port names in pi_aj_axis.v)"
    close_project
    exit 2
  }
}
set amode [get_property interface_mode [ipx::get_bus_interfaces s_axi -of_objects $core]]
if {$amode ne "slave"} {
  puts "PI_AJ_IP: FAIL - s_axi was inferred as '$amode', expected slave"
  close_project
  exit 2
}
puts "PI_AJ_IP_SELFCHECK: OK - s_axi (AXI4-Lite slave), s_axis_x, m_axis_y on aclk"

close_project
file delete -force [file join $ip_dir ".pkg_project"]
puts "PI_AJ_IP: PASS - $ip_dir/component.xml (antsdr:gnss:pi_aj:5.0)"
