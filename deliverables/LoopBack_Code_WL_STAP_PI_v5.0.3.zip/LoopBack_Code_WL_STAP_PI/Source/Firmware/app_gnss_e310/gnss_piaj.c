/******************************************************************************
 *  gnss_piaj.c  --  driver for the WL-STAP-PI v5 anti-jam core. See gnss_piaj.h.
 *****************************************************************************/

#include "gnss_piaj.h"
#include "gnss_aj.h"
#include "gnss_aj_math.h"
#include "no_os_axi_io.h"
#include "no_os_delay.h"
#include "console.h"

uint32_t gnss_piaj_read(uint32_t off)
{
	uint32_t v = 0;
	no_os_axi_io_read(GNSS_PIAJ_BASEADDR, off, &v);
	return v;
}

void gnss_piaj_write(uint32_t off, uint32_t v)
{
	no_os_axi_io_write(GNSS_PIAJ_BASEADDR, off, v);
}

int gnss_piaj_present(void)
{
	return gnss_piaj_read(PIAJ_REG_ID) == PIAJ_ID;
}

double gnss_piaj_max_fs(void)
{
	uint32_t cps = gnss_piaj_read(PIAJ_REG_CAPS) >> 24;
	if(cps == 0) cps = 5;                  /* a 5.0.1 core without CAPS */
	return GNSS_PIAJ_CLK_HZ / (double)cps;
}

static uint32_t ctrl_keep(void)
{
	/* bits the operator may have set (freeze) survive the switching */
	return gnss_piaj_read(PIAJ_REG_CONTROL) & PIAJ_FREEZE;
}

void gnss_piaj_bypass(void)
{
	gnss_piaj_write(PIAJ_REG_CONTROL, ctrl_keep() | (PIAJ_CTRL_RUN & ~PIAJ_CORE_EN));
}

void gnss_piaj_restart(void)
{
	gnss_piaj_write(PIAJ_REG_CMD, 1U);
}

void gnss_piaj_set_shift(int shift)
{
	uint32_t a = gnss_piaj_read(PIAJ_REG_ADAPT) & ~(0x1FU << 20);
	if(shift < 0) shift = 0;
	if(shift > PIAJ_MAX_SHIFT) shift = PIAJ_MAX_SHIFT;
	gnss_piaj_write(PIAJ_REG_ADAPT, a | ((uint32_t)shift << 20));
}

void gnss_piaj_run(int shift)
{
	gnss_piaj_set_shift(shift);
	gnss_piaj_write(PIAJ_REG_CONTROL, ctrl_keep() | PIAJ_CTRL_RUN);
}

int gnss_piaj_running(void)
{
	return (gnss_piaj_read(PIAJ_REG_CONTROL) & PIAJ_CORE_EN) ? 1 : 0;
}

void gnss_piaj_freeze(int on)
{
	uint32_t c = gnss_piaj_read(PIAJ_REG_CONTROL);
	gnss_piaj_write(PIAJ_REG_CONTROL, on ? (c | PIAJ_FREEZE) : (c & ~PIAJ_FREEZE));
}

void gnss_piaj_set_mu(int mu)
{
	uint32_t a = gnss_piaj_read(PIAJ_REG_ADAPT) & ~0xFU;
	if(mu < 0) mu = 0;
	if(mu > 15) mu = 15;
	gnss_piaj_write(PIAJ_REG_ADAPT, a | (uint32_t)mu);
}

void gnss_piaj_set_rho_for_fs(double fs)
{
	uint32_t rho = (fs > 20.5e6) ? 7U : 6U;
	uint32_t a = gnss_piaj_read(PIAJ_REG_ADAPT);
	if(((a >> 8) & 0xFU) != rho)
		gnss_piaj_write(PIAJ_REG_ADAPT, (a & ~(0xFU << 8)) | (rho << 8));
}

int gnss_piaj_get_mu(void)
{
	return (int)(gnss_piaj_read(PIAJ_REG_ADAPT) & 0xFU);
}

static double coef_hz(uint32_t v, double fs)
{
	double re = (double)(int16_t)(v & 0xFFFFU);
	double im = (double)(int16_t)(v >> 16);
	return aj_atan2(im, re) / (2.0 * 3.14159265358979) * fs;
}

static void read_weight(unsigned k, double *re, double *im)
{
	gnss_piaj_write(PIAJ_REG_WSEL, k);
	/* the selection crosses into the core and the value back: < 1 us */
	no_os_udelay(2);
	*re = (double)(int32_t)gnss_piaj_read(PIAJ_REG_W_RE) / 268435456.0;
	*im = (double)(int32_t)gnss_piaj_read(PIAJ_REG_W_IM) / 268435456.0;
}

void gnss_piaj_get(gnss_piaj_state_t *s, double fs, int with_weights)
{
	s->status  = gnss_piaj_read(PIAJ_REG_STATUS);
	s->control = gnss_piaj_read(PIAJ_REG_CONTROL);
	s->caps    = gnss_piaj_read(PIAJ_REG_CAPS);
	s->clipcnt = gnss_piaj_read(PIAJ_REG_CLIPCNT);
	s->samples = gnss_piaj_read(PIAJ_REG_SAMPLES);
	s->p_rx1   = (double)gnss_piaj_read(PIAJ_REG_P_RX1)   / 256.0;
	s->p_rx2   = (double)gnss_piaj_read(PIAJ_REG_P_RX2)   / 256.0;
	s->p_notch = (double)gnss_piaj_read(PIAJ_REG_P_NOTCH) / 256.0;
	s->p_out   = (double)gnss_piaj_read(PIAJ_REG_P_OUT)   / 256.0;
	s->supp_db = (s->p_out > 0.0 && s->p_rx1 > 0.0) ? aj_db10(s->p_rx1 / s->p_out) : 0.0;
	s->notch1_hz = coef_hz(gnss_piaj_read(PIAJ_REG_NOTCH1_A), fs);
	s->notch2_hz = coef_hz(gnss_piaj_read(PIAJ_REG_NOTCH2_A), fs);
	s->nw = (int)(s->caps & 0xFFU);
	if(s->nw <= 0 || s->nw > 40) s->nw = 19;
	s->wn2 = 0.0;
	s->wc_re = s->wc_im = 0.0;
	if(with_weights) {
		int k;
		uint32_t keep = gnss_piaj_read(PIAJ_REG_WSEL);
		/* index L-1+D = RX2 centre tap (L = CAPS[15:8]) */
		int L = (int)((s->caps >> 8) & 0xFFU), kc;
		if(L <= 0) L = 5;
		kc = (L - 1) + (L - 1) / 2;
		for(k = 0; k < s->nw; k++) {
			double re, im;
			read_weight((unsigned)k, &re, &im);
			s->wn2 += re * re + im * im;
			if(k == kc) { s->wc_re = re; s->wc_im = im; }
		}
		gnss_piaj_write(PIAJ_REG_WSEL, keep);
	}
}

void gnss_piaj_print(double fs)
{
	gnss_piaj_state_t s;
	uint32_t ver;
	double mag, ph;
	if(!gnss_piaj_present()) {
		console_print("WL-STAP-PI: pi_aj_0 not found at 0x%x: the bitstream is not a WL-STAP-PI v5 build\n"
			      "       (program the BOOT.BIN built from LoopBack_Code_WL_STAP_PI)\n",
			      (long)GNSS_PIAJ_BASEADDR);
		return;
	}
	ver = gnss_piaj_read(PIAJ_REG_VERSION);
	gnss_piaj_get(&s, fs, 1);
	mag = aj_sqrt(s.wc_re * s.wc_re + s.wc_im * s.wc_im);
	ph  = aj_atan2(s.wc_im, s.wc_re) * 180.0 / 3.14159265358979;
	console_print("\n--- WL-STAP-PI v5 @ 0x%x (core %d.%d.%d) ---\n", (long)GNSS_PIAJ_BASEADDR,
		      (long)(ver >> 16), (long)((ver >> 8) & 0xFFU), (long)(ver & 0xFFU));
	console_print(" structure     : CW notch + I/Q-image notch + widely-linear space-time power inversion\n"
		      "                 (%d taps per antenna, %d weights, %d lanes, %d clocks per sample:\n"
		      "                 max %s MS/s at 100 MHz)\n",
		      (long)((s.caps >> 8) & 0xFFU), (long)s.nw, (long)((s.caps >> 16) & 0xFFU),
		      (long)(s.caps >> 24), gnss_fmt(gnss_piaj_max_fs() / 1e6, 2));
	console_print(" control       : 0x%x  %s%s, PI step 2^-%d%s, make-up shift %d (+%d dB)\n",
		      (long)s.control, (char*)((s.control & PIAJ_CORE_EN) ? "FILTER IN" : "BYPASS (TX1 = RX1)"),
		      (char*)((s.control & PIAJ_FREEZE) ? ", FROZEN" : ""), (long)gnss_piaj_get_mu(),
		      (char*)((s.control & PIAJ_AUTO_MU) ? " (+1 while a CW is notched)" : ""),
		      (long)((gnss_piaj_read(PIAJ_REG_ADAPT) >> 20) & 0x1FU),
		      (long)(6 * ((gnss_piaj_read(PIAJ_REG_ADAPT) >> 20) & 0x1FU)));
	console_print(" notch 1       : %s, line at %s kHz from the LO\n",
		      (char*)((s.status & PIAJ_ST_NOTCH1) ? "ACTIVE" : "idle (no narrowband jammer)"),
		      gnss_fmt(s.notch1_hz / 1e3, 1));
	console_print(" image notch   : %s (I/Q image of notch 1, at %s kHz)\n",
		      (char*)((s.status & PIAJ_ST_IMAGE) ? "ACTIVE" : "idle"), gnss_fmt(-s.notch1_hz / 1e3, 1));
	console_print(" notch 2       : %s\n", (char*)((s.status & PIAJ_ST_NOTCH2) ? "ACTIVE" : "idle / not built"));
	console_print(" powers        : RX1 %s, RX2 %s, after notches %s, PI output %s LSB^2\n",
		      gnss_fmt(s.p_rx1, 1), gnss_fmt(s.p_rx2, 1), gnss_fmt(s.p_notch, 1), gnss_fmt(s.p_out, 1));
	console_print(" suppression   : %s dB RMS (RX1 / PI output)\n", gnss_fmt(s.supp_db, 1));
	console_print(" RX2 centre w  : %s %s j   |w| %s   phase %s deg   (sum |w|^2 %s)\n",
		      gnss_fmt(s.wc_re, 4), gnss_fmt(s.wc_im, 4), gnss_fmt(mag, 4), gnss_fmt(ph, 1),
		      gnss_fmt(s.wn2, 3));
	console_print(" ADC clipping  : %d of 1048576 samples%s\n", (long)s.clipcnt,
		      (char*)((s.status & PIAJ_ST_OVERLOAD) ? "  <-- OVERLOAD: lower the RX gain" : ""));
	if(s.status & (PIAJ_ST_LATE | PIAJ_ST_OVERRUN))
		console_print(" WARNING       : %s%s -> the sample rate is above what the core takes\n",
			      (char*)((s.status & PIAJ_ST_LATE) ? "late " : ""),
			      (char*)((s.status & PIAJ_ST_OVERRUN) ? "overrun" : ""));
	console_print(" samples       : %d\n", (long)s.samples);
	console_print("-----------------------------------\n");
}
