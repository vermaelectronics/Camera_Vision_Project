# WL-STAP-PI v5.0.3: power inversion that works at the "20 dB" jammer setting

Firmware **5.0.3**, filter IP **pi_aj 5.0** (RTL rev 5.0.3), built on the SMI-PI v4.5.0 project.
Algorithm: **WL-STAP-PI** = Notch-aided Widely-Linear Space-Time Adaptive Processing, Power Inversion (NLMS); see **`WL_STAP_PI.md`**.
**Only the anti-jam filter was replaced.** Everything else is the v4.5.0 code:
- the AD9361 setup;
- `gnss_passthrough` (HDL unchanged, v4.5);
- the DMA captures, jammer detector, CLEAR/JAMMED state machine and events;
- the matched RX gain loop and TX level hold;
- `gnss_report?`, CSV and all the console commands.

> Build commands, step by step to BOOT.BIN: **`BUILD_STEPS.md`**.
> Console tests: **`TESTING_PUTTY.md`** (section 0 is new for WL-STAP-PI).

## 1. Why SMI-PI stopped at about the "30" setting

| Field data | What it means |
|---|---|
| `peak J/N +61.1 dB` at the 30 dB setting | The jammer already fills the 12-bit ADC with the RX gain cut to keep it off full scale. |
| `WARNING residual +4.6 ... +4.9 dB` every 5 s | One spatial null (two antennas) cannot remove the CW **and** its AD9361 I/Q image (a mirror line at the opposite frequency, with a different spatial signature). Block weights from 4096-sample captures also lag the jammer. |
| CW on 1575.4: 4 GPS only, 116 s TTFF, at 15 dB nothing | A sharp CW sits on the C/A main lobe. The spatial null was not deep enough. |

## 2. What WL-STAP-PI v5 does (in the FPGA, every sample)

```
 RX1,RX2 -> CW notch -> I/Q-image notch -> widely-linear space-time POWER INVERSION -> x 2^shift -> TX1
            (tunes     (conj of the        (5 taps on RX1 and RX2 + conjugate taps,
             itself)    notch freq.)        RX1 centre tap fixed to 1, NLMS)
```

1. **CW notch.** Lag-1 autocorrelation tracks the strongest spectral line. The notch
   switches in only when it actually removes power. The **same** notch runs on RX1
   and RX2, so the jammer's direction is unchanged for step 3. A CW jammer no longer
   uses the array's only spatial null.
2. **Image notch.** At the mirror frequency, it removes the AD9361 I/Q image of the
   CW. This is what left SMI-PI's +4.8 dB residual.
3. **Power inversion.** It minimises the output power with RX1's centre tap fixed at 1,
   using 2 antennas × 5 taps plus conjugate (widely-linear) taps (19 weights). It is
   adapted with a normalised LMS on **every sample**, so it follows a moving or
   switching jammer at once, with no ARM solve. The conjugate taps null the I/Q image
   of a wideband jammer. The time taps absorb RX1/RX2 filter mismatch and multipath.
4. **Make-up shift.** The firmware sets it exactly as before: the clean output level is
   restored after the RX gain cut.

The ARM keeps detecting the jammer from DMA captures. With no jammer the filter is
**bypassed (TX1 = RX1)**. When a jammer is confirmed the ARM switches pi_aj_0 in; it
converges in well under 1 ms.

## 3. Results (RTL simulation of the exact board configuration)

These come from `Tests/pi_aj` and `pi_aj_v5/sim/run_axis.py`:
- the Icarus simulation runs `pi_aj_axis`: NL = 10, DELAY = 4, 100 MHz clock;
- samples arrive at 30.72 MS/s through a FIFO, as in the block design;
- the registers are written as the firmware writes them;
- the satellite C/N0 is measured on the 12-bit TX1 samples with a correlator.

The stimulus models:
- the 2-element array (9.52 cm), the satellite at −20° and the jammer at +55°;
- a −10 dB reflected copy of the jammer;
- RX1/RX2 gain, phase, filter and delay mismatch;
- I/Q imbalance and DC offset;
- jammer phase noise;
- a 12-bit ADC with the RX gain set so the jammer just fits.

Your terminal showed J/N 61 dB at the "30" setting. Each 10 dB of jammer adds 10 dB.

| Jammer | SMI-PI 4.5 (field) | **WL-STAP-PI v5 TX1 C/N0** (no jammer: 48.5) |
|---|---|---|
| CW 1575.40 MHz, "30" (J/N 61 dB) | +4.8 dB residual, 1 GPS + 1 GAL unstable | **46.3 dB-Hz** (−2.2 dB), 61.6 dB RMS suppression |
| CW 1575.40 MHz, **"20" (J/N 71 dB)** | not tested (15 dB: nothing) | **42.0 dB-Hz** (−6.5 dB), 68.6 dB RMS suppression (same at 18 MS/s) |
| CW 1575.40 MHz, "15" (J/N 76 dB) | no satellite | 38.8 dB-Hz (−9.7 dB) |
| CW exactly on 1575.42 MHz, J/N 71 dB | — | 39.3 dB-Hz |
| CW 1582.5 MHz, J/N 61 dB | (first field sheet) | 49.9 dB-Hz (no loss) |
| Barrage 18 MHz, J/N 40 dB | — | 50.8 dB-Hz (no loss) |
| Barrage 18 MHz, J/N 50 dB | — | 47.7 dB-Hz (−0.8 dB) |
| Barrage 2 MHz on L1, J/N 50 dB | — | 36.2 dB-Hz (−12.3 dB) |

Reading it for your receiver (satellites 36–39 dB-Hz average, 42–44 maximum, with no jammer):

| Setting | Expected behaviour |
|---|---|
| **"30"** | Normal tracking. |
| **"20"** | Strongest satellites at about 35–37 dB-Hz. GPS and Galileo in L1 track and hot start works. Cold-start acquisition of weak satellites is marginal. |
| **"15"** | Only the strongest may hold. |
| Below "15" (towards full power) | No digital filter on a 12-bit AD9361 can do it (section 5). |

## 4. What changed (files)

| File | Change |
|---|---|
| `Source/HDL/pi_aj/*.v` | **new**: the filter (frontend, notch, widely-linear PI, output, registers, `pi_aj_axis` wrapper) |
| `Source/IP/pi_aj/pi_aj_ip.tcl` | **new**: packages it as `antsdr:gnss:pi_aj:5.0` |
| `Source/BlockDesign/system_bd.tcl` | `smi_pi_0` → `pi_aj_0` between the same FIFOs; registers at `0x43D0_0000` (MOD-3) |
| `Source/HLS/smi_pi`, old `Tests/*` | removed (SMI-PI) |
| `Tests/pi_aj/*` | **new**: RTL self-test (stage 3), stimulus generator, correlator |
| `Automation/Linux/build_all.sh`, `steps/03_piaj.sh`, `build_report.sh` | stage 3 = WL-STAP-PI (self-test + IP); no Vitis HLS |
| `Source/Firmware/.../gnss_piaj.c/.h` | **new**: pi_aj_0 driver, `gnss_piaj?` |
| `gnss_aj.c/.h` | switches pi_aj_0 instead of solving/committing weights; reads suppression, residual and weights back; sample-rate check; boot profile L1 (30.72 MS/s) |
| `command.c/.h`, `main.c`, `gnss_info.c` | `gnss_piaj?`, `gnss_piaj_mu=`, texts |
| `Source/HDL/gnss_passthrough.v`, XDC, PS7, AD9361, DMA | **unchanged** |

## 5. Limitations

1. **The 12-bit ADC.**
   - At J/N ≈ 61 dB the jammer fills it. Above about 65 dB the satellites sink into
     the ADC's own noise: about 1 dB of C/N0 per dB of J/N, whatever the filter does.
   - "20" is the practical limit; "15" is marginal.
   - Full power at 6.5 m needs an RF change: distance or shielding, an attenuator or
     band-stop before the board, or a receiver with more ADC bits.
2. **Sample rate.**
   - pi_aj_0 shares its multipliers and takes one sample pair every 3 clocks of
     100 MHz, so at most **33.3 MS/s**.
   - Profiles `gnss_band=0` (L1, 30.72, the new boot default), `4` (20.48) and `5`
     (custom, e.g. 18 MS/s) are filtered.
   - Profiles `1`, `2` and `3` (61.44 / 50 MS/s) run **bypassed**, and the console
     says so. So with the filter in, **GLONASS G1 and BeiDou B1I are outside the
     processed band**.
3. **One spatial null.**
   - CW jammers do not need it (notches), so one CW plus one wideband jammer are
     handled.
   - Two wideband jammers from different directions are not.
   - Satellites near the jammer's null cone are lost with it.
4. **Wideband null depth** is about 30–37 dB, set by channel mismatch, multipath and
   LMS convergence. Barrage J/N above ~55 dB over the band, or ~45 dB concentrated on
   the C/A main lobe, will cost satellites.
5. **Swept or chirp jammers.** The notch tracks in ~0.2–1 ms. A fast sweep is left to
   the power inversion, as a wideband jammer.
6. **Notch cost.** While a CW is notched, about 80–90 kHz of the C/A main lobe is
   removed (≈0.4 dB).
7. **Not yet on the board.**
   - Simulation only. Vivado synthesis and timing of this exact design were **not**
     run here: yosys estimates the core at 138 DSP48 and about 19k LUT on the 7020
     (see section 6).
   - Check `BUILD_TIMING: MET` and the utilisation in step 10.
   - Expect the field numbers a few dB worse than simulation (AD9361 spurs, LO leakage).

## 6. Resources and timing

Estimate from yosys `synth_xilinx` (xc7) for `pi_aj_axis` as built here (NL = 10,
DELAY = 4, no notch 2):

| Resource | Estimate | Note |
|---|---|---|
| DSP48E1 | **138** of 220 | The SMI-PI HLS core it replaces used DSPs too. |
| LUT | ≈ 19.1k | |
| FF | ≈ 13.8k | |

Vivado's numbers will differ; step 10 (`10_report.sh`) prints the real
utilisation and timing.

The core and the AXI-Lite slave run on `sys_cpu_clk` = 100 MHz (10 ns), with one
clock domain inside. RTL rev **5.0.3** (VERSION register 0x00050003) is pipelined
for 100 MHz, after the first Vivado run showed WNS -0.375 ns on `clk_fpga_0`:
- every DSP48 has registered operands and a registered product;
- notch: registered coefficient and rho*coefficient, a*x[n] formed one sample
  ahead, r1 / power / gating / frequency estimator each in their own clock;
- power inversion: update shifted in two stages, weight read one clock before
  its update is added (no forwarding), output rounding preloaded into the
  accumulator, power normaliser in 4 stages (bit-exact with 5.0.2);
- output AGC and monitors: square, difference and accumulate in separate clocks,
  saturation by sign-bit checks.
On the board, `gnss_piaj?` prints `--- WL-STAP-PI v5 @ 0x43d00000 (core 5.0.3) ---`;
any other core version means an old bitstream is loaded.

## 7. Registers (pi_aj_0, 0x43D0_0000)

See the header of `Source/HDL/pi_aj/pi_aj_axil_regs.v`.

| Offset | Register | Contents |
|---|---|---|
| 0x08 | CONTROL | the firmware writes `0x41B` (filter in) or `0x41A` (bypass) |
| 0x0C | ADAPT | step, notch width, **make-up shift [24:20]** |
| 0x20 | STATUS | notches active, overload, late/overrun |
| 0x24 / 0x30 | P_RX1 / P_OUT | suppression |
| 0x34 | NOTCH1_A | jammer frequency |
| 0x40 / 0x44 | weights | weights |
| 0x4C | CAPS | clocks per sample, lanes, taps, weights |
