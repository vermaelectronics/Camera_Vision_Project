#!/usr/bin/env bash
# ============================================================================
#  selftest.sh  --  WL-STAP-PI v5 RTL self-test (build_all.sh stage "piaj")
#
#  Runs the EXACT RTL of this build (Source/HDL/pi_aj, top pi_aj_axis with
#  NL=10, DELAY=4, no notch #2) in Icarus Verilog, the way the board drives it:
#  samples arrive at 30.72 MS/s against the 100 MHz sys_cpu_clk through a FIFO,
#  and the registers are written as the firmware writes them. The jammer is a
#  CW at 1575.40 MHz (-20 kHz from the LO), J/N 61 dB (the field test's "30 dB"
#  setting), with I/Q imbalance, channel mismatch, multipath and a 12-bit ADC.
#
#  PASS needs: every input sample produced one output, no late/overrun flag,
#  RMS suppression >= 50 dB and satellite C/N0 >= 40 dB-Hz at TX1
#  (expected about 61 dB and 46 dB-Hz; no jammer gives about 49).
#
#  Needs: iverilog (sudo apt install iverilog), python3 with numpy.
#  Time: about 2 minutes. Work files: Build/PiAjSim.
# ============================================================================
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
WORK="$ROOT/Build/PiAjSim"
mkdir -p "$WORK"
cd "$WORK"

echo "PI_AJ_RTLSIM: stimulus (CW 1575.40 MHz, J/N 61 dB, 100000 samples)"
python3 "$HERE/gen_stimulus.py" --name cw61 --jn 61 --n 100000

echo "PI_AJ_RTLSIM: compiling the RTL"
iverilog -g2005 -o tbx.vvp "$HERE/tb_pi_aj_axis.v" "$ROOT"/Source/HDL/pi_aj/*.v

# make-up shift 1 (the stimulus' RX gain cut is ~9.5 dB), AGC off, as the firmware
echo "PI_AJ_RTLSIM: simulating (about 1-2 min)"
vvp -n tbx.vvp +IN=cw61.hex +OUT=cw61 +FS_MHZ=30.72 +CTRL=41B +ADAPT=0018C600 | tee sim.log

python3 - "$HERE" <<'EOF'
import sys, re
import numpy as np
sys.path.insert(0, sys.argv[1])
import analyze
log = open("sim.log").read()
meta = np.load("cw61.npz")
raw = np.loadtxt("cw61.hex", dtype=str)
v = np.vectorize(lambda s: int(s, 16))(raw[:, :2]).astype(np.int64)
v[v >= 32768] -= 65536
x0 = v[:, 0] + 1j * v[:, 1]
y = np.loadtxt("cw61_y.txt")
y = (y[:, 0] + 1j * y[:, 1]) / 2.0
settle = int(meta["jon"]) + 18000
rin = analyze.report("in", x0, 0, meta, settle)
rout = analyze.report("out", y, 0, meta, settle)
supp = 10 * np.log10(rin["power"] / rout["power"])
m = re.search(r"samples in (\d+), out (\d+)", log)
st = re.search(r"STATUS\s+=\s+([0-9a-f]+)", log)
nin, nout = int(m.group(1)), int(m.group(2))
status = int(st.group(1), 16)
ok = (nin == nout and nin > 0 and not (status & 0x30) and supp >= 50.0 and rout["cn0"] >= 40.0)
print("PI_AJ_RTLSIM: RX1 C/N0 %.1f dB-Hz -> TX1 C/N0 %.1f dB-Hz, RMS suppression %.1f dB, "
      "samples %d in / %d out, late %d, overrun %d"
      % (rin["cn0"], rout["cn0"], supp, nin, nout, (status >> 4) & 1, (status >> 5) & 1))
print("PI_AJ_RTLSIM: %s" % ("PASS" if ok else "FAIL"))
sys.exit(0 if ok else 1)
EOF
