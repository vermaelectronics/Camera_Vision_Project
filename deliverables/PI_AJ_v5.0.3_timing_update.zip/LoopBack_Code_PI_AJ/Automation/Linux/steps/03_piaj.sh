#!/usr/bin/env bash
# Step 3: PI-AJ v5 anti-jam core -> Build/ip_repo/pi_aj (replaces the SMI-PI HLS step).
#   Runs the RTL self-test first if iverilog + python3-numpy are installed
#   (want PI_AJ_RTLSIM: PASS), then packages the IP (want PI_AJ_IP: PASS).
#   The last line shows the RTL revision in Source/HDL/pi_aj and in the
#   packaged IP; both must read 5.0.3 (the timing-closed RTL).
set -e
cd "$(dirname "$0")/../../.."
./Automation/Linux/build_all.sh --from piaj --to piaj
echo "---- check ----"
grep -hE "^PI_AJ_RTLSIM:" Build/Logs/piaj_sim.log 2>/dev/null || echo "PI_AJ_RTLSIM: skipped (sudo apt install iverilog python3-numpy)"
grep -E "^PI_AJ_IP:" Build/Logs/piaj.log | tail -1
rev() { grep -hoE "VERSION = 32'h000500[0-9A-Fa-f]{2}" "$@" 2>/dev/null | head -1 | sed -E "s/.*h000500(..)/5.0.\1/; s/5\.0\.0/5.0./"; }
SRC_REV=$(rev Source/HDL/pi_aj/pi_aj_axil_regs.v)
IP_REV=$(find Build/ip_repo/pi_aj -name pi_aj_axil_regs.v -exec grep -hoE "VERSION = 32'h000500[0-9A-Fa-f]{2}" {} + 2>/dev/null | head -1 | sed -E "s/.*h000500(..)/5.0.\1/; s/5\.0\.0/5.0./")
echo "PI_AJ_RTL: source ${SRC_REV:-?}  packaged IP ${IP_REV:-?}  (want 5.0.3 for both)"
