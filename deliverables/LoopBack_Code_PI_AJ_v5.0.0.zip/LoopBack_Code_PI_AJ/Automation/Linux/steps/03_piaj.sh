#!/usr/bin/env bash
# Step 3: PI-AJ v5 anti-jam core -> Build/ip_repo/pi_aj (replaces the SMI-PI HLS step).
#   Runs the RTL self-test first if iverilog + python3-numpy are installed
#   (want PI_AJ_RTLSIM: PASS), then packages the IP (want PI_AJ_IP: PASS).
set -e
cd "$(dirname "$0")/../../.."
./Automation/Linux/build_all.sh --from piaj --to piaj
echo "---- check ----"
grep -hE "^PI_AJ_RTLSIM:" Build/Logs/piaj_sim.log 2>/dev/null || echo "PI_AJ_RTLSIM: skipped (sudo apt install iverilog python3-numpy)"
grep -E "^PI_AJ_IP:" Build/Logs/piaj.log | tail -1
