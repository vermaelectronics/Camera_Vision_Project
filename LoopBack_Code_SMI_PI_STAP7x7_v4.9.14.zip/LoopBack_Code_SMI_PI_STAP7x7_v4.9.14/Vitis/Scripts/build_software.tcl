# ============================================================================
#  build_software.tcl   (XSCT script)  --  DEFAULT software flow for 2023.2
#
#  Creates a Vitis platform from the exported XSA and builds the bare-metal
#  application from Source/Firmware.
#
#  WHY XSCT ON 2023.2
#    Vitis 2023.2 still ships XSCT and the classic (non-SDT) BSP generator.
#    That is the flow the vendor no-OS firmware was written against, so on
#    2023.2 it is the most reliable route.  (XSCT was removed in Vitis 2026.1,
#    which is why build_software.py exists; that script also runs on 2023.2.)
#
#  Requirement 15 (hardware/software sync): the platform is regenerated from
#  the XSA that the FPGA build just produced, so a hardware change always
#  propagates.  Requirement 14: the workspace it creates is a normal Vitis
#  classic workspace and opens with "vitis -classic -workspace <ws>".
#
#  Sources are COPIED into the workspace (importsources); the workspace is
#  disposable and Source/Firmware stays the single authoritative copy
#  (requirement 9).
#
#  USAGE
#    xsct build_software.tcl <xsa> <workspace> <firmware_src> <elf_out> [defines]
#      [defines]  optional comma-separated build-variant defines without -D,
#                 e.g. "GNSS_DEPLOY_AUTO_TX".  They are written into the
#                 workspace copy of gnss_build_defines.h (see that file for why
#                 a generated header is used instead of -D flags).
#
#  SUCCESS MARKER
#    Prints "SW_RESULT: PASS" only after an ELF actually exists on disk.
# ============================================================================

if {$argc < 4} {
  puts "SW_RESULT: FAIL - usage: build_software.tcl <xsa> <workspace> <firmware_src> <elf_out> \[defines\]"
  exit 2
}

set xsa       [file normalize [lindex $argv 0]]
set ws        [file normalize [lindex $argv 1]]
set fw_src    [file normalize [lindex $argv 2]]
set elf_out   [file normalize [lindex $argv 3]]
set defines   {}
if {$argc > 4} {
  foreach d [split [lindex $argv 4] ","] {
    set d [string trim $d]
    if {$d ne ""} { lappend defines $d }
  }
}

set plat_name "e310_gnss_platform"
set app_name  "e310_gnss_app"
# Vitis 2023.2 XSCT names the platform's default domain "standalone_domain";
# later releases use "standalone_ps7_cortexa9_0".  Both are tried below.
set domain_candidates {standalone_domain standalone_ps7_cortexa9_0}

foreach f [list $xsa $fw_src] {
  if {![file exists $f]} {
    puts "SW_RESULT: FAIL - missing input: $f"
    exit 2
  }
}

# The workspace is regenerated every run, never patched, so it cannot drift
# from the XSA or from Source/ (requirements 11, 15).
if {[file exists $ws]} { file delete -force $ws }
file mkdir $ws
setws $ws

# ---- platform --------------------------------------------------------------
puts "SW_STAGE: creating platform from [file tail $xsa]"
if {[catch {
  platform create -name $plat_name -hw $xsa -proc ps7_cortexa9_0 \
                  -os standalone -out $ws -no-boot-bsp
  # 4.9.6: --defines GNSS_LOG_SD saves the periodic snapshot log on the SD card with FatFs (xilffs library).
  # Not added otherwise, so a normal build is unchanged. If the library cannot be added the build goes on and
  # the compile of gnss_log.c then fails on ff.h: build without GNSS_LOG_SD in that case.
  if {[lsearch -glob $defines "GNSS_LOG_SD*"] >= 0} {
    set sd_added 0
    foreach dom $domain_candidates {
      if {![catch {
        platform active $plat_name
        domain active $dom
        bsp setlib -name xilffs
      } sd_err]} { set sd_added 1; break }
    }
    if {$sd_added} { puts "SW_NOTE: xilffs added to the BSP (GNSS_LOG_SD)" } \
    else { puts "SW_NOTE: xilffs could NOT be added: $sd_err" }
  }
  platform write
  platform generate
} err]} {
  puts "SW_RESULT: FAIL - platform create/generate"
  puts "SW_ERROR: $err"
  exit 2
}

# ---- application -----------------------------------------------------------
puts "SW_STAGE: creating application"
set app_created 0
set err ""
foreach domain $domain_candidates {
  if {![catch {
    app create -name $app_name -platform $plat_name -domain $domain \
               -template "Empty Application(C)"
  } err]} {
    set app_created 1
    break
  }
}
if {!$app_created} {
  puts "SW_RESULT: FAIL - app create"
  puts "SW_ERROR: $err"
  exit 2
}
puts "SW_DOMAIN: $domain"

puts "SW_STAGE: importing firmware from $fw_src"
# Only ask for the linker script to be imported if the firmware ships one;
# otherwise keep the lscript.ld the template generated.
if {[llength [glob -nocomplain -directory $fw_src *.ld]] > 0} {
  importsources -name $app_name -path $fw_src -linker-script
} else {
  importsources -name $app_name -path $fw_src
}

# ---- build-variant defines -> generated header -----------------------------
set hdr [file join $ws $app_name src gnss_build_defines.h]
if {![file exists $hdr]} {
  puts "SW_RESULT: FAIL - gnss_build_defines.h not found in the imported sources"
  puts "SW_EVIDENCE: expected $hdr"
  exit 2
}
set fh [open $hdr w]
puts $fh "/* GENERATED by build_software.tcl -- do not edit. */"
puts $fh "#ifndef GNSS_BUILD_DEFINES_H_"
puts $fh "#define GNSS_BUILD_DEFINES_H_"
puts $fh ""
if {[llength $defines] == 0} {
  puts $fh "/* no build-variant defines */"
} else {
  foreach d $defines {
    set eq [string first "=" $d]
    if {$eq >= 0} {
      puts $fh "#define [string trim [string range $d 0 [expr {$eq-1}]]] [string trim [string range $d [expr {$eq+1}] end]]"
    } else {
      puts $fh "#define $d 1"
    }
  }
}
puts $fh ""
puts $fh "#endif /* GNSS_BUILD_DEFINES_H_ */"
close $fh
puts "SW_DEFINES_HEADER: $hdr"
puts "SW_EXTRA_DEFINES: [expr {[llength $defines] ? [join $defines { }] : {(none)}}]"

# The no-OS AD9361 driver needs these to compile for this board.  They mirror
# app_config.h; setting them here as well means include order cannot matter.
app config -name $app_name -add define-compiler-symbols XILINX_PLATFORM
app config -name $app_name -add define-compiler-symbols ANTSDR_E310

puts "SW_STAGE: building"
if {[catch {app build -name $app_name} err]} {
  puts "SW_RESULT: FAIL - app build"
  puts "SW_ERROR: $err"
  exit 2
}

set elf ""
foreach cand [list [file join $ws $app_name Debug "${app_name}.elf"] \
                   [file join $ws $app_name Release "${app_name}.elf"] \
                   [file join $ws $app_name build "${app_name}.elf"]] {
  if {[file exists $cand]} { set elf $cand; break }
}
if {$elf eq ""} {
  puts "SW_RESULT: FAIL - build reported success but no ELF was found"
  puts "SW_EVIDENCE: looked in [file join $ws $app_name]"
  exit 2
}

file mkdir [file dirname $elf_out]
file copy -force $elf $elf_out
puts "SW_ELF_SOURCE: $elf"
puts "SW_ELF: $elf_out ([file size $elf_out] bytes)"
puts "SW_RESULT: PASS"
exit 0
