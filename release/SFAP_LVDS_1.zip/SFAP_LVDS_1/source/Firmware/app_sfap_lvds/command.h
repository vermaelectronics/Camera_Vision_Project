/**************************************************************************//**
 *   @file   command.h
 *   @brief  Header file of AD9361 Command Driver.
 *   @author DBogdan (dragos.bogdan@analog.com)
 *******************************************************************************
 * Copyright 2013(c) Analog Devices, Inc.
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *  - Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *  - Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *  - Neither the name of Analog Devices, Inc. nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *  - The use of this software may or may not infringe the patent rights
 *    of one or more patent holders.  This license does not release you
 *    from the requirement that you obtain separate licenses from these
 *    patent holders to use this software.
 *  - Use of the software either in source or binary form, must be run
 *    on or directly connected to an Analog Devices Inc. component.
 *
 * THIS SOFTWARE IS PROVIDED BY ANALOG DEVICES "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, NON-INFRINGEMENT,
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL ANALOG DEVICES BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, INTELLECTUAL PROPERTY RIGHTS, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*******************************************************************************/
#ifndef __COMMAND_H__
#define __COMMAND_H__

/******************************************************************************/
/********************** Macros and Constants Definitions **********************/
/******************************************************************************/
#define NULL		((void *)0)
#define SUCCESS		0
#define ERROR		-1

/******************************************************************************/
/*************************** Types Declarations *******************************/
/******************************************************************************/
typedef void (*cmd_function)(double* param, char param_no);
typedef struct
{
	const char* name;
	const char* description;
	const char* example;
	cmd_function function;
}command;

/******************************************************************************/
/************************ Functions Declarations ******************************/
/******************************************************************************/

/* Displays all available commands. */
void get_help(double* param, char param_no);

/* Gets the specified register value. */
void get_register(double* param, char param_no);

/* Gets current TX LO frequency. */
void get_tx_lo_freq(double* param, char param_no);

/* Sets the TX LO frequency. */
void set_tx_lo_freq(double* param, char param_no);

/* Gets current TX sampling frequency. */
void get_tx_samp_freq(double* param, char param_no);

/* Sets the TX sampling frequency. */
void set_tx_samp_freq(double* param, char param_no);

/* Gets current TX RF bandwidth. */
void get_tx_rf_bandwidth(double* param, char param_no);

/* Sets the TX RF bandwidth. */
void set_tx_rf_bandwidth(double* param, char param_no);

/* Gets current TX1 attenuation. */
void get_tx1_attenuation(double* param, char param_no);

/* Sets the TX1 attenuation. */
void set_tx1_attenuation(double* param, char param_no);

/* Gets current TX2 attenuation. */
void get_tx2_attenuation(double* param, char param_no);

/* Sets the TX2 attenuation. */
void set_tx2_attenuation(double* param, char param_no);

/* Gets current TX FIR state. */
void get_tx_fir_en(double* param, char param_no);

/* Sets the TX FIR state. */
void set_tx_fir_en(double* param, char param_no);

/* Gets current RX LO frequency. */
void get_rx_lo_freq(double* param, char param_no);

/* Sets the RX LO frequency. */
void set_rx_lo_freq(double* param, char param_no);

/* Gets current RX sampling frequency. */
void get_rx_samp_freq(double* param, char param_no);

/* Sets the RX sampling frequency. */
void set_rx_samp_freq(double* param, char param_no);

/* Gets current RX RF bandwidth. */
void get_rx_rf_bandwidth(double* param, char param_no);

/* Sets the RX RF bandwidth. */
void set_rx_rf_bandwidth(double* param, char param_no);

/* Gets current RX1 GC mode. */
void get_rx1_gc_mode(double* param, char param_no);

/* Sets the RX1 GC mode. */
void set_rx1_gc_mode(double* param, char param_no);

/* Gets current RX2 GC mode. */
void get_rx2_gc_mode(double* param, char param_no);

/* Sets the RX2 GC mode. */
void set_rx2_gc_mode(double* param, char param_no);

/* Gets current RX1 RF gain. */
void get_rx1_rf_gain(double* param, char param_no);

/* Sets the RX1 RF gain. */
void set_rx1_rf_gain(double* param, char param_no);

/* Gets current RX2 RF gain. */
void get_rx2_rf_gain(double* param, char param_no);

/* Sets the RX2 RF gain. */
void set_rx2_rf_gain(double* param, char param_no);

/* Gets current RX FIR state. */
void get_rx_fir_en(double* param, char param_no);

/* Sets the RX FIR state. */
void set_rx_fir_en(double* param, char param_no);

/* Gets current DDS TX1 Tone 1 frequency [Hz]. */
void get_dds_tx1_tone1_freq(double* param, char param_no);

/* Sets the DDS TX1 Tone 1 frequency [Hz]. */
void set_dds_tx1_tone1_freq(double* param, char param_no);

/* Gets current DDS TX1 Tone 2 frequency [Hz]. */
void get_dds_tx1_tone2_freq(double* param, char param_no);

/* Sets the DDS TX1 Tone 2 frequency [Hz]. */
void set_dds_tx1_tone2_freq(double* param, char param_no);

/* Gets current DDS TX1 Tone 1 phase [degrees]. */
void get_dds_tx1_tone1_phase(double* param, char param_no);

/* Sets the DDS TX1 Tone 1 phase [degrees]. */
void set_dds_tx1_tone1_phase(double* param, char param_no);

/* Gets current DDS TX1 Tone 2 phase [degrees]. */
void get_dds_tx1_tone2_phase(double* param, char param_no);

/* Sets the DDS TX1 Tone 2 phase [degrees]. */
void set_dds_tx1_tone2_phase(double* param, char param_no);

/* Gets current DDS TX1 Tone 1 scale. */
void get_dds_tx1_tone1_scale(double* param, char param_no);

/* Sets the DDS TX1 Tone 1 scale. */
void set_dds_tx1_tone1_scale(double* param, char param_no);

/* Gets current DDS TX1 Tone 2 scale. */
void get_dds_tx1_tone2_scale(double* param, char param_no);

/* Sets the DDS TX1 Tone 2 scale. */
void set_dds_tx1_tone2_scale(double* param, char param_no);

/* Gets current DDS TX2 Tone 1 frequency [Hz]. */
void get_dds_tx2_tone1_freq(double* param, char param_no);

/* Sets the DDS TX2 Tone 1 frequency [Hz]. */
void set_dds_tx2_tone1_freq(double* param, char param_no);

/* Gets current DDS TX2 Tone 2 frequency [Hz]. */
void get_dds_tx2_tone2_freq(double* param, char param_no);

/* Sets the DDS TX2 Tone 2 frequency [Hz]. */
void set_dds_tx2_tone2_freq(double* param, char param_no);

/* Gets current DDS TX2 Tone 1 phase [degrees]. */
void get_dds_tx2_tone1_phase(double* param, char param_no);

/* Sets the DDS TX2 Tone 1 phase [degrees]. */
void set_dds_tx2_tone1_phase(double* param, char param_no);

/* Gets current DDS TX2 Tone 2 phase [degrees]. */
void get_dds_tx2_tone2_phase(double* param, char param_no);

/* Sets the DDS TX2 Tone 2 phase [degrees]. */
void set_dds_tx2_tone2_phase(double* param, char param_no);

/* Gets current DDS TX2 Tone 1 scale. */
void get_dds_tx2_tone1_scale(double* param, char param_no);

/* Sets the DDS TX2 Tone 1 scale. */
void set_dds_tx2_tone1_scale(double* param, char param_no);

/* Gets current DDS TX2 Tone 2 scale. */
void dds_tx2_tone2_scale(double* param, char param_no);

/* Sets the DDS TX2 Tone 2 scale. */
void set_dds_tx2_tone2_scale(double* param, char param_no);

/* GNSS-CRPA MOD-6: live console control of the L1 retransmit path.
 * See Docs/Architecture/MODIFICATIONS.md. */

/* Gets the GNSS L1 retransmit state, read back from hardware. */
void get_gnss_tx(double* param, char param_no);

/* 1 = retransmit RX1 on TX1 at MAXIMUM attenuation, 0 = silence TX1.
 * gnss_tx=0 is the abort path and is safe to issue at any time. */
void set_gnss_tx(double* param, char param_no);

/* Prints AD9361 and gnss_passthrough runtime state. */
void get_gnss_status(double* param, char param_no);

/* SMI-PI v4.1 space-time anti-jam (bitstream v4.1, gnss_aj.c).
 * sfap-pi=1/0 switches it on/off (on by default; gnss_tx=1 also switches
 * it on), sfap-pi_freeze= holds the filter, sfap-pi_aj? prints the state,
 * sfap-pi_report? everything, sfap-pi_log= sets the periodic status line,
 * sfap-pi_csv= a CSV line, sfap-pi_mode= the filter, gnss_band= the RF
 * profile. No loading or other tuning value to set. */
void get_gnss_smi(double* param, char param_no);
void set_gnss_smi(double* param, char param_no);
void set_gnss_smi_freeze(double* param, char param_no);
void set_gnss_smi_hold(double* param, char param_no);   /* v6.1 */
void set_gnss_aj_blank(double* param, char param_no);   /* v6.3 */
void set_gnss_aj_excise(double* param, char param_no);  /* v6.3 */
void get_gnss_aj(double* param, char param_no);
void get_gnss_report(double* param, char param_no);
void set_gnss_aj_log(double* param, char param_no);
void set_gnss_aj_csv(double* param, char param_no);
void set_gnss_aj_mode(double* param, char param_no);
void get_gnss_band(double* param, char param_no);
void set_gnss_band(double* param, char param_no);
void set_gnss_band_custom(double* param, char param_no);
void set_gnss_band_manual(double* param, char param_no);
void get_gnss_rx_gain(double* param, char param_no);
void set_gnss_rx_gain(double* param, char param_no);
void set_gnss_rx_agc(double* param, char param_no);

/* GNSS-CRPA MOD-9: the main menu, bound to "?".
 * Short and grouped, unlike get_help() which dumps all ~60 vendor commands. */
void get_menu(double* param, char param_no);

/* GNSS-CRPA MOD-7: the DDR round trip.
 * RX -> DMA -> DDR -> DMA -> axi_ad9361 -> TX1 (pass_en = 0 branch). */

/* Gets the DDR round-trip replay state. */
void get_gnss_ddr_tx(double* param, char param_no);

/* 1 = capture RX to DDR and replay it cyclically on TX1, 0 = stop.
 * gnss_ddr_tx=0 is the abort path and is safe to issue at any time. */
void set_gnss_ddr_tx(double* param, char param_no);

#endif  // __COMMAND_H__
