# Build commands for crpa28: sources -> BOOT.BIN

This package builds **crpa28** only. `./build_all.sh` with no `--algo`
builds it, and all outputs go to `Build/crpa28/`. The result is
**`Build/crpa28/boot/BOOT.BIN`**.
The firmware is **bare-metal (no-OS)**, not Linux: `BOOT.BIN` boots straight
into FSBL, then the bitstream, then `app_crpa_lvds.elf`.

## 1. Unzip and set up the tools (once per shell)

```bash
unzip CRPA_LVDS_crpa28.zip
```

```bash
cd CRPA_LVDS_crpa28/Automation/Linux
```

```bash
chmod +x *.sh ../../Source/HDL/sim/run_iverilog.sh ../../Source/Firmware/host_test/run_engine_test.sh
```

```bash
source /tools/Xilinx/Vivado/2023.2/settings64.sh
```

```bash
source /tools/Xilinx/Vitis_HLS/2023.2/settings64.sh
```

```bash
source /tools/Xilinx/Vitis/2023.2/settings64.sh
```

If your ADI hdl tree (the one with `projects/passthrough_lvds`) is not the
default in `env.sh`, point to it:

```bash
export ADI_HDL_DIR=$HOME/CRPA_Project/NEW_PASSTHROUGH/workspace/antsdr-fw-patch/plutosdr-fw/hdl
```

## 2. Check

```bash
./build_all.sh --only check
```

## 3. Build to BOOT.BIN (all stages, roughly 40-100 minutes)

```bash
mkdir -p ../../Build
```

```bash
./build_all.sh 2>&1 | tee ../../Build/build_crpa28.log
```

The result is `Build/crpa28/boot/BOOT.BIN`, with its sha256 in
`Build/crpa28/boot/BOOT.BIN.sha256`.

## 4. The same, stage by stage

Each stage logs to `Build/crpa28/logs/<stage>.log`.

```bash
./build_all.sh --only hls     # Vitis HLS: C-sim (6 scenarios) + synthesis + IP stap_pi 1.0
```

```bash
./build_all.sh --only ip      # package gnss_passthrough 4.0 with crpa28's sizes
```

```bash
./build_all.sh --only hdl     # Vivado project passthrough_lvds_crpa28: bitstream + XSA (timing must be met)
```

```bash
./build_all.sh --only sw      # firmware + crpa28 solver -> FSBL + app_crpa_lvds.elf
```

```bash
./build_all.sh --only boot    # bootgen -> Build/crpa28/boot/BOOT.BIN
```

To restart from one stage and run everything after it:

```bash
./build_all.sh --from hdl
```

## 5. Optional checks, no Xilinx tools needed (gcc, iverilog)

```bash
../../Source/HDL/sim/run_iverilog.sh
```

```bash
../../Source/Firmware/host_test/run_engine_test.sh crpa28
```

```bash
./csim_gcc.sh
```

The last one needs the ap_int / hls_stream headers: a Vitis HLS install, or
`AP_INC=<dir>`.

## 6. On the board

Copy `Build/crpa28/boot/BOOT.BIN` to the root of a FAT32 SD card, set the boot
jumpers to SD and power up. On the console, check:

- `gnss_status?` shows version 7.0 and AJ_INFO 0x1C0A0507;
- `crpa_report?` shows "CRPA crpa28 (stap_pi)".

Or run it over JTAG straight after the build:

```bash
./build_all.sh --from boot --jtag
```
