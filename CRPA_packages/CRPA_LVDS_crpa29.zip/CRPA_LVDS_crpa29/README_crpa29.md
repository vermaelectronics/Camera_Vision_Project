# CRPA_LVDS_crpa29: Passthrough_LVDS + CRPA anti-jam, algorithm **crpa29** (ANTSDR E310)

This package is the CRPA_LVDS v7.0 pipeline for **one** algorithm, crpa29. It
builds one bitstream, one firmware and one `BOOT.BIN`, all for crpa29. The
commands are in **[BUILD_COMMANDS_crpa29.md](BUILD_COMMANDS_crpa29.md)**.

| | crpa29 |
|---|---|
| FPGA core | `stap_pi` 1.0 (Vitis HLS, II = 1 at 100 MHz), instance `crpa_core_0` |
| taps | 14 on RX1 + 14 on RX2, reference delay 7 (RX1 tap fixed at 1), 3 + 3 image taps |
| adaptive weights | 33 complex weights, Q3.12 with a weight scale ws |
| DSP48 (core, estimate) | about 103 of the Zynq-7020's 220 |
| RX -> TX filter delay | 7 samples (the same in bypass) |
| AJ_INFO | `0x1D0E0707` (the firmware refuses any other bitstream) |
| operating system | **none: bare-metal (no-OS)**. The Xilinx standalone BSP on Cortex-A9 core 0 with the Analog Devices no-OS AD9361 driver. `BOOT.BIN` = FSBL + bitstream + `app_crpa_lvds.elf`; no U-Boot, Linux kernel, device tree or root filesystem. |
| ARM solver | STAP-NLMS: a direct (Wiener, Cholesky) solve on the first capture of a jammer, then NLMS on every capture (2 passes, step from the J/N); moving-jammer tracking re-solves directly when the null is lost; weight prediction commits weights predicted half a hold interval ahead while a moving jammer leaves the held ones behind. |

The algorithm sources are `Source/CRPA/crpa29/fpga` (FPGA core) and
`Source/CRPA/crpa29/arm` (ARM solver), exactly as delivered. The build uses
them unchanged. Around them are `gnss_passthrough` v7.0 (weight registers),
the block design, the ARM engine `app_crpa_lvds` and the build scripts.

## Test results in this package (`test/`)

C simulation, the real core with the real ARM solver (`Automation/Linux/csim_gcc.sh`):

    scenario 1 core accuracy: 0 of 17832 outputs off by more than 1 LSB (bypass: exact)
    scenario 2 wideband 40 dB: J/N 40.0 dB, suppression 49.1 dB (min 30), residual 0.20 dB (max 3.0), output noise +3.04 dB, |w|^2 1.001, 6 captures, 0 solver failures -> PASS
    scenario 3 CW 45 dB: J/N 45.0 dB, suppression 59.9 dB (min 35), residual 0.00 dB (max 3.0), output noise +0.22 dB, |w|^2 0.037, 6 captures, 0 solver failures -> PASS
    scenario 4 wideband 40 dB, 2-tap RX2 channel, RX2 -6 dB: J/N 40.0 dB, suppression 46.5 dB (min 25), residual 0.23 dB (max 3.0), output noise +4.02 dB, |w|^2 1.488, 8 captures, 0 solver failures -> PASS
    scenario 5 no jammer: J/N -99.0 dB, suppression 0.0 dB (min 0), residual 0.00 dB (max 1.0), output noise +0.10 dB, |w|^2 0.020, 4 captures, 0 solver failures -> PASS
    scenario 6 wideband 40 dB, moving 2 deg/capture: J/N 40.0 dB, suppression 44.7 dB (min 20), residual 0.65 dB (max 6.0), output noise +3.00 dB, |w|^2 1.004, 12 captures, 0 solver failures -> PASS

ARM engine on the host, with simulated captures, registers and filter
(`Source/Firmware/host_test/run_engine_test.sh`):

    ENGINE_TB: static jammer: mean residual of the committed weights over their hold 0.25 dB (worst 0.43), 100 commits
    ENGINE_TB: moving jammer: mean residual 2.39 dB (worst 2.80) over 77 commits
    ENGINE_TB: PASS  crpa29

HDL register / commit testbench (`Source/HDL/sim/run_iverilog.sh`):

    HDL_TB: PASS  crpa29  (235 checks; NT 14, REF 7, wts 28 words, 28 used, wcj 6)

Not done here, because these need the Xilinx tools:

- Vitis HLS synthesis (`build_hls.tcl` stops if II > 1 or the clock is over 10 ns);
- Vivado implementation and timing (`build_all.sh` stops if timing is not met);
- the ARM toolchain build;
- any run on the board.

## Console

| command | |
|---|---|
| `crpa=1` / `crpa=0` | anti-jam on (default) / off |
| `crpa?`, `crpa_aj?`, `crpa_report?` | state, status, everything |
| `crpa_log=N`, `crpa_csv=N` | status line every N s, CSV line every N ms |
| `crpa_freeze=1/0` | hold the filter as it is |
| `crpa_direct=0..8` | direct solves at the start of a jammer (default 1) |
| `crpa_track=1/0` | re-solve when a moving jammer leaves the null (default on) |
| `crpa_predict=1/0` | weight prediction for a moving jammer (default on) |
| `crpa_passes=1..8` | NLMS passes over each capture (default 2) |

Moving jammers: tracking and prediction are on by default; `crpa_report?` shows the re-solves, the prediction state and the lead.

Two antennas give one spatial null (plus its reflections), so two jammers from
two directions are beyond this algorithm.

## Register map (gnss_passthrough v7.0)

| offset | register | |
|---|---|---|
| 0x180 | AJ_COMMIT | a write hands every shadow register to the core at once; a read gives the commit count |
| 0x184 | AJ_INFO | 0x1D0E0707 = {algorithm 29, 14 taps, REF 7, layout 7} |
| 0x188 | AJ_CFG | [0] bypass, [10:8] make-up shift, [14:12] weight scale |
| 0x18C | AJ_NORM | RX2 normalisation g2, Q3.13 |
| 0x190 | AJ_GAIN | fine output gain, Q2.14 (stap_pi only) |
| 0x198 | AJ_CFG_ACTIVE | AJ_CFG as committed |
| 0x19C | AJ_DIMS | {0, 6 image words, 28 weight words, 28 port words} |
| 0x1000 + 4k | AJ_W[k] | weight k (k < 14: RX1 delay k, then RX2), shadow |
| 0x1100 + 4c | AJ_WC[c] | image tap c, shadow |
