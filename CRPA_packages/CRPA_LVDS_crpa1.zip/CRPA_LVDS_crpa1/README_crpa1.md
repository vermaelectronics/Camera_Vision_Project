# CRPA_LVDS_crpa1: Passthrough_LVDS + CRPA anti-jam, algorithm **crpa1** (ANTSDR E310)

This package is the CRPA_LVDS v7.0 pipeline for **one** algorithm, crpa1. It
builds one bitstream, one firmware and one `BOOT.BIN`, all for crpa1. The
commands are in **[BUILD_COMMANDS_crpa1.md](BUILD_COMMANDS_crpa1.md)**.

| | crpa1 |
|---|---|
| FPGA core | `smi_pi` 4.9 (Vitis HLS, II = 1 at 100 MHz), instance `crpa_core_0` |
| taps | 6 on RX1 + 6 on RX2, reference delay 3 (RX1 tap fixed at 1), 1 + 1 image taps |
| adaptive weights | 13 complex weights, Q3.12 with a weight scale ws |
| DSP48 (core, estimate) | about 41 of the Zynq-7020's 220 |
| RX -> TX filter delay | 3 samples (the same in bypass) |
| AJ_INFO | `0x01060307` (the firmware refuses any other bitstream) |
| operating system | **none: bare-metal (no-OS)**. The Xilinx standalone BSP on Cortex-A9 core 0 with the Analog Devices no-OS AD9361 driver. `BOOT.BIN` = FSBL + bitstream + `app_crpa_lvds.elf`; no U-Boot, Linux kernel, device tree or root filesystem. |
| ARM solver | SMI power inversion: statistics of each 8192-sample capture averaged with the previous ones (adaptive), solved by Cholesky with diagonal loading from the canceller's own noise; slow-sweep detector (long memory for a slowly sweeping chirp); 4 tap modes (crpa_mode=). |

The algorithm sources are `Source/CRPA/crpa1/fpga` (FPGA core) and
`Source/CRPA/crpa1/arm` (ARM solver), exactly as delivered. The build uses
them unchanged. Around them are `gnss_passthrough` v7.0 (weight registers),
the block design, the ARM engine `app_crpa_lvds` and the build scripts.

## Test results in this package (`test/`)

C simulation, the real core with the real ARM solver (`Automation/Linux/csim_gcc.sh`):

    scenario 1 core accuracy: 0 of 17928 outputs off by more than 1 LSB (bypass: exact)
    scenario 2 wideband 40 dB: J/N 40.0 dB, suppression 55.7 dB (min 30), residual -0.01 dB (max 3.0), output noise +3.04 dB, |w|^2 1.000, 6 captures, 0 solver failures -> PASS
    scenario 3 CW 45 dB: J/N 45.0 dB, suppression 60.0 dB (min 35), residual -0.01 dB (max 3.0), output noise +0.45 dB, |w|^2 0.101, 6 captures, 0 solver failures -> PASS
    scenario 4 wideband 40 dB, 2-tap RX2 channel, RX2 -6 dB: J/N 40.0 dB, suppression 51.3 dB (min 25), residual -0.00 dB (max 3.0), output noise +4.04 dB, |w|^2 1.506, 8 captures, 0 solver failures -> PASS
    scenario 5 no jammer: J/N -99.0 dB, suppression 0.0 dB (min 0), residual 0.00 dB (max 1.0), output noise +0.00 dB, |w|^2 0.000, 4 captures, 0 solver failures -> PASS
    scenario 6 wideband 40 dB, moving 2 deg/capture (crpa1: no prediction, informational): J/N 40.0 dB, suppression 26.1 dB (min 20), residual 11.07 dB (max 6.0), output noise +3.00 dB, |w|^2 0.999, 12 captures, 0 solver failures -> INFO

ARM engine on the host, with simulated captures, registers and filter
(`Source/Firmware/host_test/run_engine_test.sh`):

    ENGINE_TB: static jammer: mean residual of the committed weights over their hold 0.00 dB (worst 0.01), 100 commits
    ENGINE_TB: moving jammer: mean residual 17.77 dB (worst 18.12) over 77 commits
    ENGINE_TB: note - crpa1 has no weight prediction; moving-jammer residual is informational
    ENGINE_TB: PASS  crpa1

HDL register / commit testbench (`Source/HDL/sim/run_iverilog.sh`):

    HDL_TB: PASS  crpa1  (263 checks; NT 6, REF 3, wts 64 words, 12 used, wcj 2)

Not done here, because these need the Xilinx tools:

- Vitis HLS synthesis (`build_hls.tcl` stops if II > 1 or the clock is over 10 ns);
- Vivado implementation and timing (`build_all.sh` stops if timing is not met);
- the ARM toolchain build;
- any run on the board.

## Console

| command | |
|---|---|
| `crpa=1` / `crpa=0` | anti-jam on (default) / off |
| `crpa?`, `crpa_aj?`, `crpa_report?` | state, status, everything |
| `crpa_log=N`, `crpa_csv=N` | status line every N s, CSV line every N ms |
| `crpa_freeze=1/0` | hold the filter as it is |
| `crpa_mode=0..3` | tap set: 0 = RX1 + RX2 taps + image (default), 1 = RX2 taps + image, 2 = one weight, 3 = no image taps |

crpa1 has **no weight prediction**: its weights are one capture old, so a jammer that keeps moving leaks (C-sim: 11 dB at 2 degrees per capture). crpa27..31 are built for that case.

Two antennas give one spatial null (plus its reflections), so two jammers from
two directions are beyond this algorithm.

## Register map (gnss_passthrough v7.0)

| offset | register | |
|---|---|---|
| 0x180 | AJ_COMMIT | a write hands every shadow register to the core at once; a read gives the commit count |
| 0x184 | AJ_INFO | 0x01060307 = {algorithm 1, 6 taps, REF 3, layout 7} |
| 0x188 | AJ_CFG | [0] bypass, [10:8] make-up shift, [14:12] weight scale |
| 0x18C | AJ_NORM | RX2 normalisation g2, Q3.13 |
| 0x190 | AJ_GAIN | fine output gain, Q2.14 (stap_pi only) |
| 0x198 | AJ_CFG_ACTIVE | AJ_CFG as committed |
| 0x19C | AJ_DIMS | {0, 2 image words, 12 weight words, 64 port words} |
| 0x1000 + 4k | AJ_W[k] | weight k (k < 6: RX1 delay k, then RX2), shadow |
| 0x1100 + 4c | AJ_WC[c] | image tap c, shadow |
