# CRPA_LVDS_stap7x7: Passthrough_LVDS + CRPA anti-jam, algorithm **stap7x7** (ANTSDR E310)

This package is the CRPA_LVDS v7.0 pipeline for **one** algorithm, stap7x7. It
builds one bitstream, one firmware and one `BOOT.BIN`, all for stap7x7. The
commands are in **[BUILD_COMMANDS_stap7x7.md](BUILD_COMMANDS_stap7x7.md)**.

| | stap7x7 |
|---|---|
| FPGA core | `stap_pi` 1.0 (Vitis HLS, II = 1 at 100 MHz), instance `crpa_core_0` |
| taps | 7 on RX1 + 7 on RX2, reference delay 3 (RX1 tap fixed at 1), 3 + 3 image taps |
| adaptive weights | 19 complex weights, Q3.12 with a weight scale ws |
| DSP48 (core, estimate) | about 61 of the Zynq-7020's 220 |
| RX -> TX filter delay | 3 samples (the same in bypass) |
| AJ_INFO | `0x4D070307` (the firmware refuses any other bitstream) |
| operating system | **none: bare-metal (no-OS)**. The Xilinx standalone BSP on Cortex-A9 core 0 with the Analog Devices no-OS AD9361 driver. `BOOT.BIN` = FSBL + bitstream + `app_crpa_lvds.elf`; no U-Boot, Linux kernel, device tree or root filesystem. |
| ARM solver | STAP-NLMS: a direct (Wiener, Cholesky) solve on the first capture of a jammer, then NLMS on every capture (2 passes, step from the J/N); moving-jammer tracking re-solves directly when the null is lost; weight prediction commits weights predicted half a hold interval ahead while a moving jammer leaves the held ones behind. |

The algorithm sources are `Source/CRPA/stap7x7/fpga` (FPGA core) and
`Source/CRPA/stap7x7/arm` (ARM solver), exactly as delivered. The build uses
them unchanged. Around them are `gnss_passthrough` v7.0 (weight registers),
the block design, the ARM engine `app_crpa_lvds` and the build scripts.

## Test results in this package (`test/`)

C simulation, the real core with the real ARM solver (`Automation/Linux/csim_gcc.sh`):



ARM engine on the host, with simulated captures, registers and filter
(`Source/Firmware/host_test/run_engine_test.sh`):



HDL register / commit testbench (`Source/HDL/sim/run_iverilog.sh`):



Not done here, because these need the Xilinx tools:

- Vitis HLS synthesis (`build_hls.tcl` stops if II > 1 or the clock is over 10 ns);
- Vivado implementation and timing (`build_all.sh` stops if timing is not met);
- the ARM toolchain build;
- any run on the board.

## Console

| command | |
|---|---|
| `crpa=1` / `crpa=0` | anti-jam on (default) / off |
| `crpa?`, `crpa_aj?`, `crpa_report?` | state, status, everything |
| `crpa_log=N`, `crpa_csv=N` | status line every N s, CSV line every N ms |
| `crpa_freeze=1/0` | hold the filter as it is |
| `crpa_direct=0..8` | direct solves at the start of a jammer (default 1) |
| `crpa_track=1/0` | re-solve when a moving jammer leaves the null (default on) |
| `crpa_predict=1/0` | weight prediction for a moving jammer (default on) |
| `crpa_passes=1..8` | NLMS passes over each capture (default 2) |

Moving jammers: tracking and prediction are on by default; `crpa_report?` shows the re-solves, the prediction state and the lead.

Two antennas give one spatial null (plus its reflections), so two jammers from
two directions are beyond this algorithm.

## Register map (gnss_passthrough v7.0)

| offset | register | |
|---|---|---|
| 0x180 | AJ_COMMIT | a write hands every shadow register to the core at once; a read gives the commit count |
| 0x184 | AJ_INFO | 0x4D070307 = {algorithm 77, 7 taps, REF 3, layout 7} |
| 0x188 | AJ_CFG | [0] bypass, [10:8] make-up shift, [14:12] weight scale |
| 0x18C | AJ_NORM | RX2 normalisation g2, Q3.13 |
| 0x190 | AJ_GAIN | fine output gain, Q2.14 (stap_pi only) |
| 0x198 | AJ_CFG_ACTIVE | AJ_CFG as committed |
| 0x19C | AJ_DIMS | {0, 6 image words, 14 weight words, 14 port words} |
| 0x1000 + 4k | AJ_W[k] | weight k (k < 7: RX1 delay k, then RX2), shadow |
| 0x1100 + 4c | AJ_WC[c] | image tap c, shadow |
