# LoopBack_LVDS: ANTSDR E310 RX -> TX loop-back, no anti-jam

The plain retransmit pipeline: AD9361 RX1 -> TX1 and RX2 -> TX2 through
`gnss_passthrough` in the FPGA, with no anti-jam filter at all. Same board
support, block design, scripts and console as the CRPA builds. The build makes
one bitstream, one firmware and one `BOOT.BIN`. The commands are in
**[BUILD_COMMANDS_loopback.md](BUILD_COMMANDS_loopback.md)**.

| | loop-back |
|---|---|
| FPGA | axi_ad9361 (LVDS 2R2T) -> gnss_passthrough (elastic buffer 32 per channel, 12-bit right -> left alignment) -> axi_ad9361 DAC; RX/TX DMA unchanged |
| filter core / HLS | none (no Vitis HLS stage) |
| firmware | bare-metal (no-OS): AD9361 no-OS driver, console, RF profiles (`gnss_band=`), matched RX gain, TX interlock; no anti-jam engine |
| TX1 / TX2 | RX1 / RX2, sample for sample, delayed through the 32-deep buffer |
| gnss_passthrough | v7.0, CONTROL[5] always 0; AJ_INFO 0x00010007 (no filter) |
| BOOT.BIN | FSBL + bitstream + app_crpa_lvds.elf; no U-Boot, no Linux |

## Test results in this package (`test/`)

HDL testbenches (Icarus Verilog), the register map and the RX -> TX datapath:

    HDL_TB: PASS  crpa0  (26 checks; NT 1, REF 0, wts 1 words, 1 used, wcj 1)
    DATAPATH: ADC every 4 clk, DAC every 4 clk: 10162 samples in, 10144 out, 0 out of order
    DATAPATH: buffer level ch0 16 ch1 16, overflows 0, underflows 0, STATUS 0001000f
    DATAPATH_TB: PASS  matched rates: every sample out in order, buffer half full
    DATAPATH: ADC every 4 clk, DAC every 1 clk: 10162 samples in, 40580 out, 30420 out of order
    DATAPATH: buffer level ch0 0 ch1 0, overflows 0, underflows 30216, STATUS 0001025f
    DATAPATH_TB: PASS  TX faster than RX: buffer empty, underflows counted (the gnss_fifo? symptom)
    HDL_TB: ALL PASS

- With TX requesting samples at the same rate as RX, every sample comes out
  in order, the buffer sits at 16 of 32, and there are no over- or underflows.
- With TX requesting 4x faster, the buffer runs empty and underflows are
  counted. That is what a TX/RX rate mismatch on the board looks like: check it
  with `gnss_fifo?`.

Not done here, because these need the Xilinx tools: Vivado implementation and
timing, the ARM build, any run on the board.

## Console (PuTTY: 115200 8N1, no flow control)

| command | |
|---|---|
| `?` / `help?` | menu / every command |
| `gnss_status?` | AD9361 and gnss_passthrough state: version 7.0, counters, buffer level |
| `gnss_fifo?` | RX and TX sample rates over 1 s, buffer level, under/overflows per second, verdict |
| `gnss_dac_rate?` / `gnss_dac_rate=N` | DAC rate control (boot value 3); only to match TX to RX, see gnss_fifo? |
| `gnss_fifo_clear=1` | clear the counters and sticky flags |
| `tx1_attenuation=70000` | TX1 attenuation in mdB (70 dB was measured working; bigger = quieter) |
| `gnss_tx=1` / `gnss_tx=0` | start / stop retransmitting (stop = abort) |
| `gnss_band?` / `gnss_band=1` | RF profile (1 = all GNSS, 1582.5 MHz, 61.44 MS/s, default) |
| `gnss_rx_gain?`, `gnss_rx_gain=N`, `gnss_rx_agc=0/1/2` | RX gain |
| `gnss_ddr_tx=1/0` | DDR capture-and-replay test on TX1 |

The `crpa*` commands are present but answer "loop-back build: no anti-jam".
