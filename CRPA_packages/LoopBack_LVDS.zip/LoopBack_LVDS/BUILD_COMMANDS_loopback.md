# Build commands for the loop-back: sources -> BOOT.BIN

`./build_all.sh` builds the loop-back; outputs go to `Build/loopback/`.
The result is **`Build/loopback/boot/BOOT.BIN`**. The firmware is
bare-metal (no-OS), not Linux.

## Step 1: Xilinx tools (once per terminal)

```bash
source /tools/Xilinx/Vivado/2023.2/settings64.sh
```

```bash
source /tools/Xilinx/Vitis/2023.2/settings64.sh
```

(Vitis HLS isn't needed for the loop-back.)

## Step 2: ADI HDL tree

```bash
export ADI_HDL_DIR=/home/sandeep/antsdr/antsdr-fw-patch/plutosdr-fw/hdl
```

(Not needed once `Vendor/adi_hdl` exists, see step 9.)

## Step 3: unzip and go to the build folder

```bash
cd ~/Downloads
```

```bash
unzip LoopBack_LVDS.zip
```

```bash
cd ~/Downloads/LoopBack_LVDS/Automation/Linux
```

```bash
chmod +x *.sh
```

```bash
mkdir -p ../../Build
```

## Step 4: check (it must end with `CHECK: PASS`)

```bash
./build_all.sh --only check 2>&1 | tee ../../Build/loopback_1_check.log
```

## Step 5: IP, packaging gnss_passthrough (about 1-2 minutes; must end with `IP: PASS`)

```bash
./build_all.sh --only ip 2>&1 | tee ../../Build/loopback_2_ip.log
```

## Step 6: HDL, the Vivado bitstream (about 30-60 minutes; must end with `HDL: PASS ... (timing met)`)

```bash
./build_all.sh --only hdl 2>&1 | tee ../../Build/loopback_3_hdl.log
```

## Step 7: SW, the firmware (about 3-5 minutes; must end with `SW: PASS`)

```bash
./build_all.sh --only sw 2>&1 | tee ../../Build/loopback_4_sw.log
```

## Step 8: boot, building BOOT.BIN (must end with `BOOT: PASS`)

```bash
./build_all.sh --only boot 2>&1 | tee ../../Build/loopback_5_boot.log
```

```bash
ls -l ~/Downloads/LoopBack_LVDS/Build/loopback/boot/BOOT.BIN
```

Steps 4-8 in one command instead:

```bash
./build_all.sh 2>&1 | tee ../../Build/build_loopback.log
```

If a step fails, send the last lines of its log, for example:

```bash
tail -40 ~/Downloads/LoopBack_LVDS/Build/loopback/logs/hdl.log
```

## Step 9 (optional): one complete zip with your ADI HDL tree inside

```bash
./bundle_full.sh /home/sandeep/antsdr/antsdr-fw-patch/plutosdr-fw/hdl
```

This writes `~/Downloads/LoopBack_LVDS_full.zip`.

## On the board (PuTTY 115200 8N1)

Copy `BOOT.BIN` to the root of a FAT32 SD card, set the boot jumpers to SD and
power up. The console shows `=== ANTSDR E310 - Passthrough_LVDS LOOP-BACK (no anti-jam) ===`. Then:

```
gnss_status?
```

```
tx1_attenuation=70000
```

```
gnss_tx=1
```

```
gnss_fifo?
```

`gnss_fifo?` must say `VERDICT: OK` (buffer about 16, 0 underflows/s). If it
says TX is faster or slower, type the `gnss_dac_rate=N` it suggests, then
run `gnss_fifo?` again. Stop retransmitting with `gnss_tx=0`.
