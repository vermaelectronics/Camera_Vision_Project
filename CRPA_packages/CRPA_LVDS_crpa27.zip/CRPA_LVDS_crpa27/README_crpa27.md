# CRPA_LVDS_crpa27: Passthrough_LVDS + CRPA anti-jam, algorithm **crpa27** (ANTSDR E310)

This package is the CRPA_LVDS v7.0 pipeline for **one** algorithm, crpa27. It
builds one bitstream, one firmware and one `BOOT.BIN`, all for crpa27. The
commands are in **[BUILD_COMMANDS_crpa27.md](BUILD_COMMANDS_crpa27.md)**.

| | crpa27 |
|---|---|
| FPGA core | `stap_pi` 1.0 (Vitis HLS, II = 1 at 100 MHz), instance `crpa_core_0` |
| taps | 8 on RX1 + 8 on RX2, reference delay 4 (RX1 tap fixed at 1), 3 + 3 image taps |
| adaptive weights | 21 complex weights, Q3.12 with a weight scale ws |
| DSP48 (core, estimate) | about 67 of the Zynq-7020's 220 |
| RX -> TX filter delay | 4 samples (the same in bypass) |
| AJ_INFO | `0x1B080407` (the firmware refuses any other bitstream) |
| operating system | **none: bare-metal (no-OS)**. The Xilinx standalone BSP on Cortex-A9 core 0 with the Analog Devices no-OS AD9361 driver. `BOOT.BIN` = FSBL + bitstream + `app_crpa_lvds.elf`; no U-Boot, Linux kernel, device tree or root filesystem. |
| ARM solver | STAP-NLMS: a direct (Wiener, Cholesky) solve on the first capture of a jammer, then NLMS on every capture (2 passes, step from the J/N); moving-jammer tracking re-solves directly when the null is lost; a Kalman weight tracker (on at boot) filters the solved weights and commits them predicted half a hold interval ahead, so a moving jammer stays in the null. |

The algorithm sources are `Source/CRPA/crpa27/fpga` (FPGA core) and
`Source/CRPA/crpa27/arm` (ARM solver), exactly as delivered. The build uses
them unchanged. Around them are `gnss_passthrough` v7.0 (weight registers),
the block design, the ARM engine `app_crpa_lvds` and the build scripts.

## Test results in this package (`test/`)

C simulation, the real core with the real ARM solver (`Automation/Linux/csim_gcc.sh`):

    scenario 1 core accuracy: 0 of 17904 outputs off by more than 1 LSB (bypass: exact)
    scenario 2 wideband 40 dB: J/N 40.0 dB, suppression 50.1 dB (min 30), residual 0.15 dB (max 3.0), output noise +3.04 dB, |w|^2 1.000, 6 captures, 0 solver failures -> PASS
    scenario 3 CW 45 dB: J/N 45.0 dB, suppression 57.2 dB (min 35), residual 0.14 dB (max 3.0), output noise +0.33 dB, |w|^2 0.067, 6 captures, 0 solver failures -> PASS
    scenario 4 wideband 40 dB, 2-tap RX2 channel, RX2 -6 dB: J/N 40.0 dB, suppression 45.6 dB (min 25), residual 0.31 dB (max 3.0), output noise +4.02 dB, |w|^2 1.487, 8 captures, 0 solver failures -> PASS
    scenario 5 no jammer: J/N -99.0 dB, suppression 0.0 dB (min 0), residual 0.00 dB (max 1.0), output noise +0.13 dB, |w|^2 0.023, 4 captures, 0 solver failures -> PASS
    scenario 6 wideband 40 dB, moving 2 deg/capture: J/N 40.0 dB, suppression 44.6 dB (min 20), residual 0.63 dB (max 6.0), output noise +3.00 dB, |w|^2 1.004, 12 captures, 0 solver failures -> PASS

ARM engine on the host, with simulated captures, registers and filter
(`Source/Firmware/host_test/run_engine_test.sh`):

    ENGINE_TB: static jammer: mean residual of the committed weights over their hold 0.06 dB (worst 0.13), 100 commits
    ENGINE_TB: moving jammer: mean residual 2.19 dB (worst 3.68) over 77 commits
    ENGINE_TB: PASS  crpa27

HDL register / commit testbench (`Source/HDL/sim/run_iverilog.sh`):

    HDL_TB: PASS  crpa27  (151 checks; NT 8, REF 4, wts 16 words, 16 used, wcj 6)

Not done here, because these need the Xilinx tools:

- Vitis HLS synthesis (`build_hls.tcl` stops if II > 1 or the clock is over 10 ns);
- Vivado implementation and timing (`build_all.sh` stops if timing is not met);
- the ARM toolchain build;
- any run on the board.

## Console

| command | |
|---|---|
| `crpa=1` / `crpa=0` | anti-jam on (default) / off |
| `crpa?`, `crpa_aj?`, `crpa_report?` | state, status, everything |
| `crpa_log=N`, `crpa_csv=N` | status line every N s, CSV line every N ms |
| `crpa_freeze=1/0` | hold the filter as it is |
| `crpa_direct=0..8` | direct solves at the start of a jammer (default 1) |
| `crpa_track=1/0` | re-solve when a moving jammer leaves the null (default on) |
| `crpa_kalman=1/0` | Kalman weight tracker (default **on** at boot; 0 = off) |
| `crpa_predict=1/0` | simple weight prediction, used only while `crpa_kalman=0` (default on) |
| `crpa_passes=1..8` | NLMS passes over each capture (default 2) |

Moving jammers: tracking and the Kalman tracker are on by default; `crpa_report?` shows the re-solves, the lead and a `Kalman tracker` line (steps, manoeuvres, NIS). `crpa_kalman=0` switches the Kalman tracker off.

Two antennas give one spatial null (plus its reflections), so two jammers from
two directions are beyond this algorithm.

## Register map (gnss_passthrough v7.0)

| offset | register | |
|---|---|---|
| 0x180 | AJ_COMMIT | a write hands every shadow register to the core at once; a read gives the commit count |
| 0x184 | AJ_INFO | 0x1B080407 = {algorithm 27, 8 taps, REF 4, layout 7} |
| 0x188 | AJ_CFG | [0] bypass, [10:8] make-up shift, [14:12] weight scale |
| 0x18C | AJ_NORM | RX2 normalisation g2, Q3.13 |
| 0x190 | AJ_GAIN | fine output gain, Q2.14 (stap_pi only) |
| 0x198 | AJ_CFG_ACTIVE | AJ_CFG as committed |
| 0x19C | AJ_DIMS | {0, 6 image words, 16 weight words, 16 port words} |
| 0x1000 + 4k | AJ_W[k] | weight k (k < 8: RX1 delay k, then RX2), shadow |
| 0x1100 + 4c | AJ_WC[c] | image tap c, shadow |
