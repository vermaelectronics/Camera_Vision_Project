localparam integer CFG_LOG2_SNAP = 7;
localparam integer CFG_P_LOG2 = 2;
localparam integer CFG_MU_Q30 = 1024;
localparam integer CFG_K_Q30 = 341782638;
localparam integer CFG_USE_COV = 0;
localparam integer N_SAMPLES = 768;
localparam integer N_WINDOWS = 6;
