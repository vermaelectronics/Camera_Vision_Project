# PL-NPI v2.5: space-time core, fast-attack AGC, 20 dB TX

Version **2.5.0** of `LoopBack_Code_PL_NPI` (firmware `PL-NPI 2.5.0`, bitstream
VERSION `0x00020005`, HLS IP still `antsdr:gnss:pl_npi:2.1` so the block design
needs no change). Baseline: `LoopBack_Code_PL_NPI_v2.4.0.zip`.

The three requested corrections are applied:

| Correction | Where | What changed |
|---|---|---|
| Space-time adaptive power inversion (HLS) | `Source/HLS/pl_npi/pl_npi.cpp`, `pl_npi.h`, `testbench.cpp`, `build_hls.tcl` | The v2.4 core was **replaced**. It is now an NLMS power inversion over **2 antennas x 4 taps**, with the reference tap x1(n) held at weight 1 and 7 adaptive weights. |
| Fast-attack AGC on both RX channels | `gnss_l1.c`, `gnss_npi_agc.c`, `main.c` (init `gc_rx1/2_mode = 1`) | `RF_GAIN_SLOWATTACK_AGC` is now `RF_GAIN_FASTATTACK_AGC` on RX1 **and** RX2. |
| TX attenuation 20000 mdB (20 dB) on TX1 and TX2, clamped to 89750 | `gnss_l1.c/.h` (`set_gnss_band_tx_attenuation`), `command.c` (`gnss_tx=`) | `gnss_tx=1` now starts at **20 dB on TX1 and TX2**. `gnss_tx=0` returns both to 89.75 dB. |

## 1. HLS core: what was fixed in the proposed code

The proposed code could not be used as written. These problems were fixed:

1. **Wrong conjugate in the update.** The proposal filters with
   `y = sum conj(w) x` but updates with `w -= mu y conj(x)`, which is the gradient for
   `y = sum w x`. For complex signals this does not converge. The core now uses
   `y = sum w x` together with that update.
2. **Fixed-point overflow.** `ap_fixed<16,2> inv_norm = 1.0 / norm_sq` can only hold
   values up to ±2, and 1/0.001 = 1000. The samples also arrive at raw ADC scale
   (±2048), not ±2. The core uses the integer formats that were proven in v2.4:
   regressors Q2, weights Q12.20, and the reciprocal as an 18-bit mantissa plus
   an exponent.
3. **A divider inside the II=1 weight loop.** At II=1 the whole loop
   (8 complex MACs, a divide, the update) would have to fit in one 10 ns clock,
   and v2.3.0 already missed timing with far less logic in the loop. The divide
   now sits in the feed-forward path. The loop is split into 10 registered stages
   plus 2 delays (a delayed LMS with a 12-sample update delay, the same delay v2.3
   validated).
4. **Interface.** The port list is unchanged, so `system_bd.tcl`,
   `gnss_passthrough.v` and the register map still connect.

Kept from v2.4: modes AUTO, BYPASS, ON and HOLD, the power detector,
`adapt_en` (freeze), and the output make-up shift.
Removed with the old core: RX2 normalisation (`nrm`), image taps, the DC
blocker and the CW notches. Their ports and registers stay but are ignored.
`npi_st` reports 0 notches, DC blocker off and a new bit [9] "space-time".
Output latency is now 3 samples instead of 2.

`wout` word 0 holds the weight of x2(n). Words 1 and 2 read 0: the 6
delay-tap weights are not read back. For this reason the firmware no longer
rebuilds the output from the read-back weights. On a v2.5 bitstream it calls
`npi_measure_stap()` (`gnss_npi_det.c`), which computes the 7-weight
least-squares optimum on each capture. It also turns image-tap control off and
reports the DC blocker and notches as absent.

## 2. Verified, and how

Everything was checked **in simulation only**. Vitis HLS, Vivado and the board
were not available, so **HLS timing (II=1 at 10 ns), implementation timing and
the bitstream are not verified.** On your PC, check for `PL_NPI_HLS: PASS`
(step 3) and `BUILD_TIMING: MET` (step 6).

`Tests/run_regression.sh` (with `HLS_INCLUDE` set to the open-source ap_types
headers): **all 18 checks PASS**.

| C-sim scenario | Result |
|---|---|
| 1 CW 31 dB, mode ON | residual 0.75 dB above the noise within 4000 samples |
| 2 noise only, firmware gamma | output within 0.05 dB of RX1 (not cancelled) |
| 3 BYPASS | output == RX1 bit-exact, weights 0 |
| 4 AUTO gated | on after 2 samples, residual 0.84 dB, back to exact bypass, 1 event |
| 5 wideband 30 dB, 80 % band, 0.35-sample delay + tilt on RX2 | **14.4 dB** residual. The least-squares optimum for 7 space-time weights is 14.1 dB; for one spatial weight (the v2.4 structure) it is 24.8 dB, so the new core is **10 dB better** here |
| 6 HOLD | weights frozen, null holds (0.97 dB) |
| 7 make-up shift 2 | +12.04 dB, ignored in bypass |
| 8 AUTO, noise only | output == RX1, detector never on |

Scenarios 1, 4 and 5 also pass with 0 and 4 extra delay registers.
A CW jammer at 1900 LSB (42 dB) also nulls to 0.75 dB.

Also passed: the RTL `gnss_passthrough` testbench (VERSION 0x00020005), the
firmware CW scan, and firmware mock scenarios 1-8. Every edited firmware file
compiles cleanly against the host stubs.

## 3. Read before transmitting: 20 dB is 50 dB louder

At 20 dB attenuation TX1 puts out about **-13 dBm**. The level measured to give
a 3D fix (TEST-025) was 70 dB, about -63 dBm. Into a directly connected GNSS
receiver, 20 dB will saturate the front end. Use it only with enough external
attenuation in the coax. To go back to the previous level, either:

- run `tx1_attenuation=70000` after `gnss_tx=1`, or
- build with `--defines GNSS_TX_START_ATTEN_MDB=70000U`.

TX2 now gets the same attenuation as TX1. The SD-card deployment level
(`GNSS_DEPLOY_TX_ATTEN_MDB`, 70 dB) is unchanged.

`SD_Image/BOOT.BIN` is the earlier prebuilt image and does **not** contain v2.5.
Rebuild with `BUILD_STEPS.md` to get these changes onto the board.
