// ============================================================================
//  pl_npi.cpp  --  space-time adaptive power-inversion core (Vitis HLS), v2.5
//  ANTSDR E310 V1 / GNSS CRPA project
// ----------------------------------------------------------------------------
//  v2.5 -- WHAT CHANGED
//    The v2.4 core (one spatial RX2 weight, two I/Q image taps, input DC
//    blocker, two CW notches) is replaced by a space-time NLMS power
//    inversion: PL_NPI_ANT = 2 channels x PL_NPI_TAPS = 4 taps per channel.
//    One complex weight per antenna cannot null a WIDEBAND jammer whose RX1 and
//    RX2 paths differ in delay or frequency response (group delay, filter
//    mismatch): the tapped delay line lets each channel apply its own short
//    FIR, so the null holds across the jammer's bandwidth.
//    Removed with the old core: RX2 normalisation (nrm), image taps
//    (cfg[2]), DC blocker (cfg[3]), CW notches (cfg[13:12], ncoef). The ports
//    stay, unused, so the block design and gnss_passthrough are unchanged.
//    npi_st reports 0 notches and DC blocker off, and the firmware reads that.
//
//  ALGORITHM
//    x(n) = [x1(n), x2(n), x1(n-1), x2(n-1), ..., x1(n-3), x2(n-3)]   (8 taps)
//    w    = [1, w0, w1, ..., w6]      reference tap x1(n) held at 1
//    y(n) = sum_k w_k x_k(n)          (array output = x1(n) + sum w u)
//    w_k -= mu * y(n) conj(x_k(n)) / (||x(n)||^2 + eps),  k = 0..6
//    w_k -= w_k / 2^PL_NPI_LEAK_SHIFT (a 2^-18 leak towards 0)
//
//    mu  = 2^-PL_NPI_STEP_SHIFT (default 2^-4 = 0.0625)
//    eps = gamma / 2^17 + 1 [LSB^2], gamma from the firmware (0 allowed)
//
//    Holding x1(n) at 1 is Compton's power-inversion constraint: minimising
//    the output power can only cancel what RX2 and the delayed taps can
//    reproduce of RX1, i.e. a jammer seen by both antennas. The satellites,
//    below the noise and uncorrelated between the taps, pass at RX1's level.
//
//    The update is y conj(x), the gradient of |y|^2 for the y = sum w x
//    convention used here. (The original proposal used y = sum conj(w) x
//    with the same update, which has the wrong sign on the imaginary part
//    and does not converge for complex signals.)
//
//  FIXED POINT (raw ADC scale, 12-bit samples in 16-bit words)
//    regressors u = 4 x (Q2, 19 bits); weights Q12.20 (32 bits); the array
//    sum s at Q22; s at Q8 (25 bits, saturated) for the correlation; the
//    correlation conj(u) s at Q10 (45 bits). 1 / (||x||^2 + eps) is a
//    feed-forward divide 2^32 / den per sample, kept as an 18-bit mantissa
//    and a power-of-two exponent, so the weight loop holds one 45 x 19-bit
//    multiply and a shift instead of a divider.
//
//  PIPELINE AND TIMING (II=1 at 10 ns on sys_cpu_clk)
//    A weight update that waits for its own output cannot fit one clock: the
//    loop w -> u w -> sum -> conj(u) s -> * alpha -> w is split into
//    registers and the update uses values PL_NPI_UPDATE_DELAY samples old
//    ("delayed LMS"), as in the v2.3 / v2.4 core that met 10 ns:
//      wp -> A1 pa (u w) -> A2 p (4 partial sums) -> A2b t (2 sums)
//         -> A3 sA (s, saturated) -> B1 pb (conj(u) s) -> B2 cB (sum)
//         -> C pC (* mantissa) -> D1 vD (shift) -> D2 tD (saturate)
//         -> tQ[NQ] -> E1 dl (+ leak) -> E2 wp (subtract + saturate)
//    Each arrow is at most one wide multiply, two adds, or one add +
//    saturation. 10 + NQ registers: NQ = 2 gives a 12-sample update delay,
//    the delay the v2.3 core validated; mu is small enough for it to be
//    stable (C simulation, testbench.cpp). Output latency PL_NPI_LATENCY = 3
//    samples, the same for filter and bypass, so switching between them
//    never moves the satellites' code phase.
//
//  GATING (unchanged from v2.3)
//    cfg[1:0] mode AUTO: a power detector (|x1|^2 + |x2|^2 averaged over 64
//    samples) puts the filter in and starts the adaptation when the input
//    rises above det_thr, and returns to BYPASS det_hold samples after it
//    falls below half of it. In BYPASS TX1 = RX1 exactly and the weights are
//    held at 0, so each jammer starts from w = 0. BYPASS, ON and HOLD force
//    the state. adapt_en = 0 freezes the weights. Output make-up shift
//    cfg[10:8] (y << s, 0..4) is applied while the filter is in.
// ============================================================================
#include "pl_npi.h"

typedef ap_int<16> smp_t;     // input sample, raw ADC scale
typedef ap_int<19> reg_t;     // regressor, Q2 (raw x 4), conj-safe width
typedef ap_int<32> w_t;       // weight, Q12.20

// Pure delay registers between stage D2 and stage E1 (see "PIPELINE").
#ifndef PL_NPI_EXTRA_DELAY
#define PL_NPI_EXTRA_DELAY 2
#endif
static const int NQ = PL_NPI_EXTRA_DELAY;
// mu = 2^-PL_NPI_STEP_SHIFT.
#ifndef PL_NPI_STEP_SHIFT
#define PL_NPI_STEP_SHIFT 4
#endif
#ifndef PL_NPI_LEAK_SHIFT
#define PL_NPI_LEAK_SHIFT 18
#endif
#define PL_NPI_GAMMA_SHIFT 17      // eps = gamma / 2^17
#define PL_NPI_DET_SHIFT 6         // detector average over 2^6 samples
#define PL_NPI_DET_FRAC  8         // fraction bits of the detector average
#define NW   PL_NPI_NW             // 7 adaptive weights
#define ND   (PL_NPI_TAPS - 1)     // delayed samples per channel

static ap_int<16> sat16(ap_int<64> v) {
#pragma HLS INLINE
    if (v > 32767)  return 32767;
    if (v < -32768) return -32768;
    return (ap_int<16>)v;
}

static ap_int<25> sat25(ap_int<60> v) {
#pragma HLS INLINE
    const ap_int<60> mx = (ap_int<60>(1) << 24) - 1;
    const ap_int<60> mn = -(ap_int<60>(1) << 24);
    if (v > mx) return (ap_int<25>)mx;
    if (v < mn) return (ap_int<25>)mn;
    return (ap_int<25>)v;
}

static ap_int<48> sat48(ap_int<64> v) {
#pragma HLS INLINE
    const ap_int<64> mx = (ap_int<64>(1) << 47) - 1;
    const ap_int<64> mn = -(ap_int<64>(1) << 47);
    if (v > mx) return (ap_int<48>)mx;
    if (v < mn) return (ap_int<48>)mn;
    return (ap_int<48>)v;
}

static w_t sat32(ap_int<50> v) {
#pragma HLS INLINE
    const ap_int<50> mx = 2147483647;
    const ap_int<50> mn = -2147483647 - 1;
    if (v > mx) return (w_t)mx;
    if (v < mn) return (w_t)mn;
    return (w_t)v;
}

// Index of the highest set bit (0 when v == 0).
template <int W>
static ap_uint<7> msb_index(ap_uint<W> v) {
#pragma HLS INLINE
    ap_uint<7> p = 0;
    for (int i = 0; i < W; i++) {
#pragma HLS UNROLL
        if (v[i]) p = i;
    }
    return p;
}

void pl_npi(hls::stream<ap_uint<64> > &s_axis_x,
            hls::stream<ap_uint<32> > &m_axis_y,
            ap_uint<32>  gamma,
            ap_uint<1>   adapt_en,
            ap_uint<32>  cfg,
            ap_uint<32>  nrm,
            ap_uint<32>  det_thr,
            ap_uint<32>  det_hold,
            ap_uint<192> ncoef,
            ap_uint<32>  *npi_st,
            ap_uint<192> *wout,
            ap_uint<32>  *det_pow)
{
#pragma HLS INTERFACE axis port=s_axis_x
#pragma HLS INTERFACE axis port=m_axis_y
#pragma HLS INTERFACE ap_none port=gamma
#pragma HLS INTERFACE ap_none port=adapt_en
#pragma HLS INTERFACE ap_none port=cfg
#pragma HLS INTERFACE ap_none port=nrm
#pragma HLS INTERFACE ap_none port=det_thr
#pragma HLS INTERFACE ap_none port=det_hold
#pragma HLS INTERFACE ap_none port=ncoef
#pragma HLS INTERFACE ap_none port=npi_st
#pragma HLS INTERFACE ap_none port=wout
#pragma HLS INTERFACE ap_none port=det_pow
#pragma HLS INTERFACE ap_ctrl_none port=return
#pragma HLS PIPELINE II=1
    (void)nrm;
    (void)ncoef;
    // ---- state ---------------------------------------------------------------
    // Every static below is a register; each stage reads the OLD values (they
    // are all written at the end), so each stage is one clock.
    static w_t wp_re[NW] = {0}, wp_im[NW] = {0};
    static w_t wd_re[NW] = {0}, wd_im[NW] = {0};     // wp one sample ago (leak)
#pragma HLS ARRAY_PARTITION variable=wp_re complete
#pragma HLS ARRAY_PARTITION variable=wp_im complete
#pragma HLS ARRAY_PARTITION variable=wd_re complete
#pragma HLS ARRAY_PARTITION variable=wd_im complete
#pragma HLS RESET variable=wp_re
#pragma HLS RESET variable=wp_im
#pragma HLS RESET variable=wd_re
#pragma HLS RESET variable=wd_im
    // tapped delay line: x(n-1) .. x(n-3), raw scale
    static smp_t dl1_re[ND] = {0}, dl1_im[ND] = {0}, dl2_re[ND] = {0}, dl2_im[ND] = {0};
#pragma HLS ARRAY_PARTITION variable=dl1_re complete
#pragma HLS ARRAY_PARTITION variable=dl1_im complete
#pragma HLS ARRAY_PARTITION variable=dl2_re complete
#pragma HLS ARRAY_PARTITION variable=dl2_im complete
#pragma HLS RESET variable=dl1_re
#pragma HLS RESET variable=dl1_im
#pragma HLS RESET variable=dl2_re
#pragma HLS RESET variable=dl2_im
    // per-sample power |x1|^2 + |x2|^2 of x(n-1) .. x(n-3), for ||x||^2
    static ap_uint<33> pwd[ND] = {0};
#pragma HLS ARRAY_PARTITION variable=pwd complete
#pragma HLS RESET variable=pwd
    // A1: the four real products of u * w for each weight
    static ap_int<51> pa_rr[NW], pa_ii[NW], pa_ri[NW], pa_ir[NW];
#pragma HLS ARRAY_PARTITION variable=pa_rr complete
#pragma HLS ARRAY_PARTITION variable=pa_ii complete
#pragma HLS ARRAY_PARTITION variable=pa_ri complete
#pragma HLS ARRAY_PARTITION variable=pa_ir complete
#pragma HLS RESET variable=pa_rr
#pragma HLS RESET variable=pa_ii
#pragma HLS RESET variable=pa_ri
#pragma HLS RESET variable=pa_ir
    // A2: four partial sums of s; A2b: two
    static ap_int<56> p_re[4] = {0, 0, 0, 0}, p_im[4] = {0, 0, 0, 0};
#pragma HLS ARRAY_PARTITION variable=p_re complete
#pragma HLS ARRAY_PARTITION variable=p_im complete
#pragma HLS RESET variable=p_re
#pragma HLS RESET variable=p_im
    static ap_int<58> t0_re = 0, t0_im = 0, t1_re = 0, t1_im = 0;
#pragma HLS RESET variable=t0_re
#pragma HLS RESET variable=t0_im
#pragma HLS RESET variable=t1_re
#pragma HLS RESET variable=t1_im
    // A3: s at Q.8
    static ap_int<25> sA_re = 0, sA_im = 0;
#pragma HLS RESET variable=sA_re
#pragma HLS RESET variable=sA_im
    // B1: the four real products of conj(u) * s
    static ap_int<44> pb_rr[NW], pb_ii[NW], pb_ri[NW], pb_ir[NW];
#pragma HLS ARRAY_PARTITION variable=pb_rr complete
#pragma HLS ARRAY_PARTITION variable=pb_ii complete
#pragma HLS ARRAY_PARTITION variable=pb_ri complete
#pragma HLS ARRAY_PARTITION variable=pb_ir complete
#pragma HLS RESET variable=pb_rr
#pragma HLS RESET variable=pb_ii
#pragma HLS RESET variable=pb_ri
#pragma HLS RESET variable=pb_ir
    // B2: correlation (Q10) and the step mantissa / exponent of its sample
    static ap_int<45> cB_re[NW] = {0}, cB_im[NW] = {0};
#pragma HLS ARRAY_PARTITION variable=cB_re complete
#pragma HLS ARRAY_PARTITION variable=cB_im complete
#pragma HLS RESET variable=cB_re
#pragma HLS RESET variable=cB_im
    static ap_uint<18> mB = 0;
    static ap_int<8>   eB = 0;
#pragma HLS RESET variable=mB
#pragma HLS RESET variable=eB
    // C: corr * mantissa
    static ap_int<64> pC_re[NW] = {0}, pC_im[NW] = {0};
#pragma HLS ARRAY_PARTITION variable=pC_re complete
#pragma HLS ARRAY_PARTITION variable=pC_im complete
#pragma HLS RESET variable=pC_re
#pragma HLS RESET variable=pC_im
    static ap_uint<7> rC = 0;                  // right shift into weight LSBs
#pragma HLS RESET variable=rC
    // D1: shifted into Q.20 weight units; D2: saturated
    static ap_int<64> vD_re[NW] = {0}, vD_im[NW] = {0};
#pragma HLS ARRAY_PARTITION variable=vD_re complete
#pragma HLS ARRAY_PARTITION variable=vD_im complete
#pragma HLS RESET variable=vD_re
#pragma HLS RESET variable=vD_im
    static ap_int<48> tD_re[NW] = {0}, tD_im[NW] = {0};
#pragma HLS ARRAY_PARTITION variable=tD_re complete
#pragma HLS ARRAY_PARTITION variable=tD_im complete
#pragma HLS RESET variable=tD_re
#pragma HLS RESET variable=tD_im
#if PL_NPI_EXTRA_DELAY > 0
    // tD delayed by NQ more samples before stage E1 uses it.
    static ap_int<48> tQ_re[NQ][NW], tQ_im[NQ][NW];
#pragma HLS ARRAY_PARTITION variable=tQ_re complete dim=0
#pragma HLS ARRAY_PARTITION variable=tQ_im complete dim=0
#pragma HLS RESET variable=tQ_re
#pragma HLS RESET variable=tQ_im
#define TE_RE(i) tQ_re[NQ - 1][i]
#define TE_IM(i) tQ_im[NQ - 1][i]
#else
#define TE_RE(i) tD_re[i]
#define TE_IM(i) tD_im[i]
#endif
    // E1: the update incl. the leak, in weight LSBs
    static ap_int<49> dl_re[NW] = {0}, dl_im[NW] = {0};
#pragma HLS ARRAY_PARTITION variable=dl_re complete
#pragma HLS ARRAY_PARTITION variable=dl_im complete
#pragma HLS RESET variable=dl_re
#pragma HLS RESET variable=dl_im
    // per-sample values travelling beside the sample
    static reg_t uA1_re[NW], uA1_im[NW], uA2_re[NW], uA2_im[NW];
    static reg_t uS_re[NW], uS_im[NW], uB_re[NW], uB_im[NW];
#pragma HLS ARRAY_PARTITION variable=uA1_re complete
#pragma HLS ARRAY_PARTITION variable=uA1_im complete
#pragma HLS ARRAY_PARTITION variable=uA2_re complete
#pragma HLS ARRAY_PARTITION variable=uA2_im complete
#pragma HLS ARRAY_PARTITION variable=uS_re complete
#pragma HLS ARRAY_PARTITION variable=uS_im complete
#pragma HLS ARRAY_PARTITION variable=uB_re complete
#pragma HLS ARRAY_PARTITION variable=uB_im complete
#pragma HLS RESET variable=uA1_re
#pragma HLS RESET variable=uA1_im
#pragma HLS RESET variable=uA2_re
#pragma HLS RESET variable=uA2_im
#pragma HLS RESET variable=uS_re
#pragma HLS RESET variable=uS_im
#pragma HLS RESET variable=uB_re
#pragma HLS RESET variable=uB_im
    static reg_t x1qA_re = 0, x1qA_im = 0;                         // x1 at Q2, for the sum
    static smp_t x1A_re = 0, x1A_im = 0, x1A2_re = 0, x1A2_im = 0;  // raw x1, for bypass
    static smp_t x1S_re = 0, x1S_im = 0;
#pragma HLS RESET variable=x1qA_re
#pragma HLS RESET variable=x1qA_im
#pragma HLS RESET variable=x1A_re
#pragma HLS RESET variable=x1A_im
#pragma HLS RESET variable=x1A2_re
#pragma HLS RESET variable=x1A2_im
#pragma HLS RESET variable=x1S_re
#pragma HLS RESET variable=x1S_im
    static ap_uint<18> mA1 = 0, mA2 = 0, mS = 0, mB0 = 0, mB1 = 0;
    static ap_int<8>   eA1 = 0, eA2 = 0, eS = 0, eB0 = 0, eB1 = 0;
#pragma HLS RESET variable=mA1
#pragma HLS RESET variable=mA2
#pragma HLS RESET variable=mS
#pragma HLS RESET variable=mB0
#pragma HLS RESET variable=mB1
#pragma HLS RESET variable=eA1
#pragma HLS RESET variable=eA2
#pragma HLS RESET variable=eS
#pragma HLS RESET variable=eB0
#pragma HLS RESET variable=eB1
    // power detector
    static ap_uint<34> pacc = 0;              // average, PL_NPI_DET_FRAC fraction bits
    static ap_uint<1>  det = 0;
    static ap_uint<32> hold = 0;
    static ap_uint<16> det_cnt = 0;
#pragma HLS RESET variable=pacc
#pragma HLS RESET variable=det
#pragma HLS RESET variable=hold
#pragma HLS RESET variable=det_cnt

    // ---- mode ----------------------------------------------------------------
    ap_uint<2> mode = cfg(1, 0);
    bool active = (mode == PL_NPI_MODE_ON) || (mode == PL_NPI_MODE_HOLD) ||
                  (mode == PL_NPI_MODE_AUTO && det == 1);
    bool adapt  = adapt_en && ((mode == PL_NPI_MODE_ON) ||
                               (mode == PL_NPI_MODE_AUTO && det == 1));
    ap_uint<3> sh = cfg(10, 8);
    if (sh > PL_NPI_MAXSH) sh = PL_NPI_MAXSH;

    {
        ap_uint<32> st = 0;
        st[0] = det;
        st[1] = active;
        st[4] = adapt;
        st(7, 5) = 0;                          // no CW notches
        st[8] = 0;                             // no DC blocker
        st[9] = 1;                             // space-time core
        st(31, 16) = det_cnt;
        *npi_st = st;
        ap_uint<192> wo = 0;
        wo(31, 0)  = (ap_uint<32>)wp_re[0];    // weight of x2(n)
        wo(63, 32) = (ap_uint<32>)wp_im[0];
        *wout = wo;
        *det_pow = (ap_uint<32>)(pacc >> PL_NPI_DET_FRAC);
    }

    if (s_axis_x.empty()) return;
    ap_uint<64> in = s_axis_x.read();

    smp_t x1r = (smp_t)in(15, 0),  x1i = (smp_t)in(31, 16);
    smp_t x2r = (smp_t)in(47, 32), x2i = (smp_t)in(63, 48);

    // regressors (Q2): u0 = x2(n), then x1(n-k), x2(n-k) for k = 1..3
    reg_t u_re[NW], u_im[NW];
#pragma HLS ARRAY_PARTITION variable=u_re complete
#pragma HLS ARRAY_PARTITION variable=u_im complete
    u_re[0] = (reg_t)(ap_int<19>(x2r) << 2);
    u_im[0] = (reg_t)(ap_int<19>(x2i) << 2);
    for (int k = 0; k < ND; k++) {
#pragma HLS UNROLL
        u_re[1 + 2 * k] = (reg_t)(ap_int<19>(dl1_re[k]) << 2);
        u_im[1 + 2 * k] = (reg_t)(ap_int<19>(dl1_im[k]) << 2);
        u_re[2 + 2 * k] = (reg_t)(ap_int<19>(dl2_re[k]) << 2);
        u_im[2 + 2 * k] = (reg_t)(ap_int<19>(dl2_im[k]) << 2);
    }
    reg_t x1qr = (reg_t)(ap_int<19>(x1r) << 2), x1qi = (reg_t)(ap_int<19>(x1i) << 2);

    // ---- power detector ----------------------------------------------------------
    ap_uint<33> pin = (ap_uint<33>)(x1r * x1r) + (ap_uint<33>)(x1i * x1i) +
                      (ap_uint<33>)(x2r * x2r) + (ap_uint<33>)(x2i * x2i);
    {
        ap_uint<25> pd = (pin > 0x1FFFFFF) ? ap_uint<25>(0x1FFFFFF) : (ap_uint<25>)pin;
        ap_int<36> d = (ap_int<36>)((ap_uint<34>)pd << PL_NPI_DET_FRAC) - (ap_int<36>)pacc;
        ap_uint<34> npacc = (ap_uint<34>)((ap_int<36>)pacc + (d >> PL_NPI_DET_SHIFT));
        ap_uint<32> pav = (ap_uint<32>)(pacc >> PL_NPI_DET_FRAC);
        ap_uint<1>  ndet = det;
        ap_uint<32> nhold = hold;
        if (pav > det_thr) {
            ndet = 1;
            nhold = det_hold;
        } else if (pav <= (det_thr >> 1)) {
            if (hold == 0) ndet = 0;
            else nhold = hold - 1;
        }
        if (ndet == 1 && det == 0) det_cnt = det_cnt + 1;
        det  = ndet;
        hold = nhold;
        pacc = npacc;
    }

    // ---- feed-forward: alpha = 2^32 / (||x||^2 + eps) as (18-bit mantissa,
    //      exponent). ||x||^2 over all 8 taps, eps = gamma / 2^17 + 1 ------
    ap_uint<36> den = (ap_uint<36>)pin + pwd[0] + pwd[1] + pwd[2] +
                      (ap_uint<36>)(gamma >> PL_NPI_GAMMA_SHIFT) + 1;
    ap_uint<33> q   = (ap_uint<33>(1) << 32) / den;              // Q0.32, >= 1
    ap_uint<7>  qp  = msb_index<33>(q);
    ap_uint<18> qm  = (qp >= 17) ? (ap_uint<18>)(q >> (qp - 17))
                                 : (ap_uint<18>)(q << (17 - qp));
    // update [weight LSB] = mu * corr_q10 * 2^-10 * q * 2^-32 * 2^20
    //                     = corr_q10 * qm * 2^(qp - 17 - 22 - STEP_SHIFT)
    // qp <= 32, so the exponent is always negative: a right shift.
    ap_int<8> qe = (ap_int<8>)qp - 39 - PL_NPI_STEP_SHIFT;

    // ---- E2: weights: subtract + saturate, or 0 in bypass ------------------
    w_t nwp_re[NW], nwp_im[NW];
#pragma HLS ARRAY_PARTITION variable=nwp_re complete
#pragma HLS ARRAY_PARTITION variable=nwp_im complete
    for (int i = 0; i < NW; i++) {
#pragma HLS UNROLL
        nwp_re[i] = active ? sat32((ap_int<50>)wp_re[i] - dl_re[i]) : w_t(0);
        nwp_im[i] = active ? sat32((ap_int<50>)wp_im[i] - dl_im[i]) : w_t(0);
    }

    // ---- E1: update + leak (from the weight of one sample ago), 0 while not
    //      adapting ---------------------------------------------------------------
    ap_int<49> ndl_re[NW], ndl_im[NW];
#pragma HLS ARRAY_PARTITION variable=ndl_re complete
#pragma HLS ARRAY_PARTITION variable=ndl_im complete
    for (int i = 0; i < NW; i++) {
#pragma HLS UNROLL
        ndl_re[i] = adapt ? (ap_int<49>)((ap_int<49>)TE_RE(i) + (wd_re[i] >> PL_NPI_LEAK_SHIFT)) : ap_int<49>(0);
        ndl_im[i] = adapt ? (ap_int<49>)((ap_int<49>)TE_IM(i) + (wd_im[i] >> PL_NPI_LEAK_SHIFT)) : ap_int<49>(0);
    }

    // ---- D2: saturate to 48 bits; D1: shift into weight units --------------
    ap_int<48> ntD_re[NW], ntD_im[NW];
    ap_int<64> nvD_re[NW], nvD_im[NW];
#pragma HLS ARRAY_PARTITION variable=ntD_re complete
#pragma HLS ARRAY_PARTITION variable=ntD_im complete
#pragma HLS ARRAY_PARTITION variable=nvD_re complete
#pragma HLS ARRAY_PARTITION variable=nvD_im complete
    for (int i = 0; i < NW; i++) {
#pragma HLS UNROLL
        ntD_re[i] = sat48(vD_re[i]);
        ntD_im[i] = sat48(vD_im[i]);
        nvD_re[i] = pC_re[i] >> rC;
        nvD_im[i] = pC_im[i] >> rC;
    }

    // ---- C: corr * mantissa -----------------------------------------------------
    ap_int<64> npC_re[NW], npC_im[NW];
#pragma HLS ARRAY_PARTITION variable=npC_re complete
#pragma HLS ARRAY_PARTITION variable=npC_im complete
    for (int i = 0; i < NW; i++) {
#pragma HLS UNROLL
        npC_re[i] = cB_re[i] * (ap_int<19>)mB;
        npC_im[i] = cB_im[i] * (ap_int<19>)mB;
    }
    ap_uint<7> nrC = (eB < -63) ? ap_uint<7>(63) : (ap_uint<7>)(-eB);

    // ---- B2: corr = conj(u) * s ---------------------------------------------------
    ap_int<45> ncB_re[NW], ncB_im[NW];
#pragma HLS ARRAY_PARTITION variable=ncB_re complete
#pragma HLS ARRAY_PARTITION variable=ncB_im complete
    for (int i = 0; i < NW; i++) {
#pragma HLS UNROLL
        ncB_re[i] = (ap_int<45>)pb_rr[i] + (ap_int<45>)pb_ii[i];
        ncB_im[i] = (ap_int<45>)pb_ri[i] - (ap_int<45>)pb_ir[i];
    }

    // ---- B1: products conj(u) * s --------------------------------------------------
    ap_int<44> npb_rr[NW], npb_ii[NW], npb_ri[NW], npb_ir[NW];
#pragma HLS ARRAY_PARTITION variable=npb_rr complete
#pragma HLS ARRAY_PARTITION variable=npb_ii complete
#pragma HLS ARRAY_PARTITION variable=npb_ri complete
#pragma HLS ARRAY_PARTITION variable=npb_ir complete
    for (int i = 0; i < NW; i++) {
#pragma HLS UNROLL
        npb_rr[i] = uB_re[i] * sA_re;
        npb_ii[i] = uB_im[i] * sA_im;
        npb_ri[i] = uB_re[i] * sA_im;
        npb_ir[i] = uB_im[i] * sA_re;
    }

    // ---- A3: s = t0 + t1 (Q22); the output; s at Q.8 for the loop ---------
    ap_int<60> s_re = (ap_int<60>)t0_re + t1_re, s_im = (ap_int<60>)t0_im + t1_im;

    // Output: bypass = x1; filter = round(s * 2^sh / 2^22), saturated. Both
    // leave PL_NPI_LATENCY samples after their input.
    ap_uint<32> out;
    if (active) {
        const ap_int<64> half = ap_int<64>(1) << 21;
        out(15, 0)  = (ap_uint<16>)sat16((((ap_int<64>)s_re << sh) + half) >> 22);
        out(31, 16) = (ap_uint<16>)sat16((((ap_int<64>)s_im << sh) + half) >> 22);
    } else {
        out(15, 0)  = (ap_uint<16>)x1S_re;
        out(31, 16) = (ap_uint<16>)x1S_im;
    }
    m_axis_y.write(out);

    // ---- A2b: two sums -------------------------------------------------------------
    ap_int<58> nt0_re = (ap_int<58>)p_re[0] + p_re[1], nt0_im = (ap_int<58>)p_im[0] + p_im[1];
    ap_int<58> nt1_re = (ap_int<58>)p_re[2] + p_re[3], nt1_im = (ap_int<58>)p_im[2] + p_im[3];

    // ---- A2: four partial sums of s = x1 + sum u * w -----------------------
    ap_int<56> np_re[4], np_im[4];
#pragma HLS ARRAY_PARTITION variable=np_re complete
#pragma HLS ARRAY_PARTITION variable=np_im complete
    np_re[0] = ((ap_int<56>)pa_rr[0] - pa_ii[0]) + ((ap_int<56>)x1qA_re << 20);
    np_im[0] = ((ap_int<56>)pa_ri[0] + pa_ir[0]) + ((ap_int<56>)x1qA_im << 20);
    for (int k = 1; k < 4; k++) {
#pragma HLS UNROLL
        const int a = 2 * k - 1, b = 2 * k;
        np_re[k] = ((ap_int<56>)pa_rr[a] - pa_ii[a]) + ((ap_int<56>)pa_rr[b] - pa_ii[b]);
        np_im[k] = ((ap_int<56>)pa_ri[a] + pa_ir[a]) + ((ap_int<56>)pa_ri[b] + pa_ir[b]);
    }

    // ---- A1: products u * w with the current weights -----------------------
    ap_int<51> npa_rr[NW], npa_ii[NW], npa_ri[NW], npa_ir[NW];
#pragma HLS ARRAY_PARTITION variable=npa_rr complete
#pragma HLS ARRAY_PARTITION variable=npa_ii complete
#pragma HLS ARRAY_PARTITION variable=npa_ri complete
#pragma HLS ARRAY_PARTITION variable=npa_ir complete
    for (int i = 0; i < NW; i++) {
#pragma HLS UNROLL
        npa_rr[i] = u_re[i] * wp_re[i];
        npa_ii[i] = u_im[i] * wp_im[i];
        npa_ri[i] = u_re[i] * wp_im[i];
        npa_ir[i] = u_im[i] * wp_re[i];
    }

    // ---- commit all registers ---------------------------------------------
    for (int i = 0; i < NW; i++) {
#pragma HLS UNROLL
        wd_re[i] = wp_re[i];   wd_im[i] = wp_im[i];
        wp_re[i] = nwp_re[i];  wp_im[i] = nwp_im[i];
        dl_re[i] = ndl_re[i];  dl_im[i] = ndl_im[i];
#if PL_NPI_EXTRA_DELAY > 0
        for (int j = NQ - 1; j > 0; j--) {
#pragma HLS UNROLL
            tQ_re[j][i] = tQ_re[j - 1][i];  tQ_im[j][i] = tQ_im[j - 1][i];
        }
        tQ_re[0][i] = tD_re[i];  tQ_im[0][i] = tD_im[i];
#endif
        tD_re[i] = ntD_re[i];  tD_im[i] = ntD_im[i];
        vD_re[i] = nvD_re[i];  vD_im[i] = nvD_im[i];
        pC_re[i] = npC_re[i];  pC_im[i] = npC_im[i];
        cB_re[i] = ncB_re[i];  cB_im[i] = ncB_im[i];
        pb_rr[i] = npb_rr[i];  pb_ii[i] = npb_ii[i];
        pb_ri[i] = npb_ri[i];  pb_ir[i] = npb_ir[i];
        uB_re[i] = uS_re[i];   uB_im[i] = uS_im[i];
        uS_re[i] = uA2_re[i];  uS_im[i] = uA2_im[i];
        uA2_re[i] = uA1_re[i]; uA2_im[i] = uA1_im[i];
        uA1_re[i] = u_re[i];   uA1_im[i] = u_im[i];
        pa_rr[i] = npa_rr[i];  pa_ii[i] = npa_ii[i];
        pa_ri[i] = npa_ri[i];  pa_ir[i] = npa_ir[i];
    }
    rC = nrC;
    mB = mB1;   eB = eB1;
    mB1 = mB0;  eB1 = eB0;
    mB0 = mS;   eB0 = eS;
    mS = mA2;   eS = eA2;
    mA2 = mA1;  eA2 = eA1;
    mA1 = qm;   eA1 = qe;
    sA_re = sat25(s_re >> 14);
    sA_im = sat25(s_im >> 14);
    t0_re = nt0_re;  t0_im = nt0_im;  t1_re = nt1_re;  t1_im = nt1_im;
    for (int k = 0; k < 4; k++) {
#pragma HLS UNROLL
        p_re[k] = np_re[k];  p_im[k] = np_im[k];
    }
    x1S_re = x1A2_re;  x1S_im = x1A2_im;
    x1A2_re = x1A_re;  x1A2_im = x1A_im;
    x1A_re = x1r;      x1A_im = x1i;
    x1qA_re = x1qr;    x1qA_im = x1qi;
    for (int k = ND - 1; k > 0; k--) {
#pragma HLS UNROLL
        dl1_re[k] = dl1_re[k - 1];  dl1_im[k] = dl1_im[k - 1];
        dl2_re[k] = dl2_re[k - 1];  dl2_im[k] = dl2_im[k - 1];
        pwd[k] = pwd[k - 1];
    }
    dl1_re[0] = x1r;  dl1_im[0] = x1i;
    dl2_re[0] = x2r;  dl2_im[0] = x2i;
    pwd[0] = pin;
}
