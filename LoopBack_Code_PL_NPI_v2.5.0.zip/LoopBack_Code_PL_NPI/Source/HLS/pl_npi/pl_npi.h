// ============================================================================
//  pl_npi.h  --  space-time adaptive power-inversion core (Vitis HLS), v2.5
//  ANTSDR E310 V1 / GNSS CRPA project
//
//  v2.5 replaces the v2.4 core (RX2 weight + image taps + DC blocker + CW
//  notches) with a space-time NLMS power inversion: PL_NPI_ANT = 2 antennas
//  x PL_NPI_TAPS = 4 taps, reference tap x1(n) held at weight 1. See
//  pl_npi.cpp for the algorithm, the fixed-point formats and the pipeline.
//
//  The port list is the same as v2.4, so Source/BlockDesign/system_bd.tcl,
//  Source/HDL/gnss_passthrough.v and the register map are unchanged.
// ============================================================================
#ifndef PL_NPI_H
#define PL_NPI_H

#include "ap_int.h"
#include "hls_stream.h"

#define PL_NPI_ANT       2     // spatial channels: RX1, RX2
#define PL_NPI_TAPS      4     // space-time taps per channel (wideband jammers)
#define PL_NPI_NW        (PL_NPI_ANT * PL_NPI_TAPS - 1)  // adaptive weights (x1(n) is fixed at 1)
#define PL_NPI_NWOUT     3     // weight words in wout
#define PL_NPI_LATENCY   3     // output sample k carries input sample k-3 (filter and bypass)

// cfg bits
#define PL_NPI_MODE_AUTO   0u  // [1:0] = 0: the power detector switches the
                               //   filter and the adaptation on and off
#define PL_NPI_MODE_BYPASS 1u  //         1: always TX1 = RX1, weights held at 0
#define PL_NPI_MODE_ON     2u  //         2: filter in and adapting, always
#define PL_NPI_MODE_HOLD   3u  //         3: filter in, weights frozen
#define PL_NPI_CFG_SH_LSB  8   // [10:8] output make-up shift, 0..4
#define PL_NPI_MAXSH       4   // largest output make-up shift (x16 = +24 dB)
// cfg[2] (image taps), cfg[3] (DC blocker) and cfg[13:12] (CW notches) were
// v2.4 features. v2.5 ignores them and reports 0 notches and DC blocker off
// in npi_st, so the firmware leaves them off.

// npi_st bits
#define PL_NPI_ST_DET      0x1u  // [0] power detector on
#define PL_NPI_ST_ACTIVE   0x2u  // [1] filter in the path (not bypassed)
#define PL_NPI_ST_ADAPT    0x10u // [4] weights adapting
#define PL_NPI_ST_NOTCH_LSB 5    // [7:5] notch filters in the core: 0 in v2.5
#define PL_NPI_ST_DCBLK    0x100u // [8] DC blocker on: 0 in v2.5
#define PL_NPI_ST_STAP     0x200u // [9] v2.5 space-time core (always 1)
#define PL_NPI_ST_CNT_LSB  16    // [31:16] detector switch-on count

// s_axis_x : {rx2_q, rx2_i, rx1_q, rx1_i}, each a signed 16-bit sample at the
//            raw ADC scale (12-bit RX samples, sign-extended, not shifted).
// m_axis_y : {y_q, y_i}, the array output at the same scale, saturated to
//            signed 16 bits.
// gamma    : NLMS regulariser. The step is normalised by
//            ||x||^2 + gamma / 2^17 [LSB^2], ||x||^2 summed over all 8 taps.
//            The firmware's automatic gamma (2^17 k x noise power) therefore
//            adds k x the noise power per channel.
// adapt_en : 0 = weights frozen (CONTROL[6], gnss_npi_freeze=1).
// cfg      : mode and make-up shift (bits above).
// nrm      : unused in v2.5 (was the RX2 normalisation g2).
// det_thr  : detector threshold on the averaged |x1|^2 + |x2|^2 [LSB^2]:
//            on above it, off det_hold samples after it falls below half.
// det_hold : see det_thr.
// ncoef    : unused in v2.5 (was the CW notch coefficients).
// npi_st   : status (bits above).
// wout     : Q12.20, word k at [64k+63 : 64k] = {imag[63:32], real[31:0]}:
//            k = 0 the RX2 weight of the current sample x2(n), the spatial
//            weight the v2.4 firmware reads as w2. k = 1, 2 read 0 (the
//            v2.4 image taps): the 6 delay-tap weights are not read back.
// det_pow  : the detector's averaged input power [LSB^2].
void pl_npi(hls::stream<ap_uint<64> > &s_axis_x,
            hls::stream<ap_uint<32> > &m_axis_y,
            ap_uint<32>  gamma,
            ap_uint<1>   adapt_en,
            ap_uint<32>  cfg,
            ap_uint<32>  nrm,
            ap_uint<32>  det_thr,
            ap_uint<32>  det_hold,
            ap_uint<192> ncoef,
            ap_uint<32>  *npi_st,
            ap_uint<192> *wout,
            ap_uint<32>  *det_pow);

#endif
