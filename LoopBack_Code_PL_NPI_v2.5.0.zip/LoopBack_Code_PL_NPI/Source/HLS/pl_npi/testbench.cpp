// ============================================================================
//  testbench.cpp  --  C simulation of the space-time power-inversion core (v2.5)
//
//  Two-element array at the E310 raw ADC scale (12-bit samples):
//      RX1 = J + n1,   RX2 = h (P * J) + n2
//  J: CW jammer, or a band-limited Gaussian jammer; h the RX2 phase/gain
//  (0.6 - 0.5j); P an RX2 path filter (scenario 5: fractional delay and a
//  tilt, which one spatial weight cannot follow across the band). n1, n2
//  independent noise, uniform +-20 LSB.
//
//  Scenario (argv[1]); each needs a freshly reset core, so the csim script
//  runs one per process. All must print "PL_NPI_CSIM: PASS".
//    1  CW 600 LSB, mode ON, gamma 0: jammer nulled to <= 1.5 dB above the
//       RX1 noise within 4000 samples, no growth afterwards
//    2  no jammer, mode ON, gamma = 2^17 x 32 x noise (the firmware's clean
//       setting): the output stays within 1 dB of RX1
//    3  bypass: mode BYPASS with a jammer: output == RX1 for every sample,
//       weights 0
//    4  gated adaptation, mode AUTO: CW jammer 31 dB on at sample 5000, off
//       at 40000: detector on within 100 samples, residual <= 1.5 dB once
//       converged, back to bypass (output == RX1, weights 0) after the hold
//       time, exactly one detector event
//    5  WIDEBAND jammer 30 dB above the noise (80 % of the band) through a
//       0.35-sample fractional delay + tilt on RX2: the core's residual is
//       within 1.5 dB of the least-squares optimum of its 7 space-time
//       weights (computed on the same noisy samples), and at least 6 dB below
//       the optimum of one spatial weight (what the v2.4 core could do)
//    6  HOLD after convergence: weights frozen, the null holds
//    7  output make-up shift: x4 (+12 dB) while filtering, ignored in bypass
//    8  mode AUTO with noise only: output == RX1, detector never on
// ============================================================================
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <complex>
#include "pl_npi.h"

typedef std::complex<double> cd;

// ---- random numbers ----------------------------------------------------------
static unsigned lcg = 12345u;
static int unoise(int a) {                 // uniform integer in [-a, a]
    lcg = lcg * 1103515245u + 12345u;
    return (int)((lcg >> 8) % (unsigned)(2 * a + 1)) - a;
}
static unsigned long long rs = 88172645463325252ULL;
static double urand() {
    rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17;
    return ((rs >> 11) + 0.5) / 9007199254740992.0;
}
static double grand() {                    // standard normal
    return std::sqrt(-2.0 * std::log(urand())) * std::cos(2.0 * M_PI * urand());
}

static int q16(double v) {
    long r = std::lround(v);
    if (r > 2047) r = 2047;                // 12-bit ADC
    if (r < -2048) r = -2048;
    return (int)r;
}

// ---- the core ------------------------------------------------------------------
struct Core {
    hls::stream<ap_uint<64> > in;
    hls::stream<ap_uint<32> > out;
    ap_uint<32> gamma = 0, cfg = PL_NPI_MODE_ON, det_thr = 0xFFFFFFFFu, det_hold = 0;
    ap_uint<1> adapt_en = 1;
    ap_uint<32> st = 0, pow = 0;
    ap_uint<192> w = 0;
    // one sample in, one out (the output belongs to the input PL_NPI_LATENCY ago)
    cd step(int x1r, int x1i, int x2r, int x2i) {
        ap_uint<64> v = 0;
        v(15, 0)  = (ap_uint<16>)(ap_int<16>)x1r;
        v(31, 16) = (ap_uint<16>)(ap_int<16>)x1i;
        v(47, 32) = (ap_uint<16>)(ap_int<16>)x2r;
        v(63, 48) = (ap_uint<16>)(ap_int<16>)x2i;
        in.write(v);
        pl_npi(in, out, gamma, adapt_en, cfg, 0x2000, det_thr, det_hold, 0, &st, &w, &pow);
        ap_uint<32> o = out.read();
        return cd((double)(ap_int<16>)o(15, 0), (double)(ap_int<16>)o(31, 16));
    }
    cd w0() const {
        return cd((double)(ap_int<32>)w(31, 0), (double)(ap_int<32>)w(63, 32)) / 1048576.0;
    }
    bool w_zero() const { return w == 0; }
};

static int fails = 0;
static void check(bool ok, const char *what) {
    printf("  %-60s %s\n", what, ok ? "ok" : "FAIL");
    if (!ok) fails++;
}
static double db(double x) { return 10.0 * std::log10(x); }

static const cd H(0.6, -0.5);
static const double NOISE_P = 2.0 * (20.0 * 21.0 / 3.0);   // E|n|^2, uniform +-20, I and Q

// A sample source: CW jammer amplitude a (0 = off) at normalised frequency f.
struct Src {
    double a = 0.0, f = 0.0123, ph = 0.0;
    void next(int &x1r, int &x1i, int &x2r, int &x2i) {
        cd j = a * std::polar(1.0, ph);
        ph += 2.0 * M_PI * f;
        cd j2 = H * j;
        x1r = q16(j.real() + unoise(20)); x1i = q16(j.imag() + unoise(20));
        x2r = q16(j2.real() + unoise(20)); x2i = q16(j2.imag() + unoise(20));
    }
};

// mean |out|^2 / RX1 noise power over [from, to)
static double residual_db(const std::vector<double> &p, int from, int to) {
    double s = 0.0;
    for (int n = from; n < to; n++) s += p[n];
    return db(s / (to - from) / NOISE_P);
}

// ---- scenarios ---------------------------------------------------------------
static void scen_cw() {
    Core c; Src s; s.a = 600.0;
    const int N = 20000;
    std::vector<double> p(N);
    for (int n = 0; n < N; n++) {
        int a, b, d, e; s.next(a, b, d, e);
        p[n] = std::norm(c.step(a, b, d, e));
    }
    double r1 = residual_db(p, 4000, 8000), r2 = residual_db(p, 15000, 20000);
    printf("  jammer %.1f dB above the noise; residual %.2f dB (4k-8k), %.2f dB (15k-20k), |w0| %.3f\n",
           db(600.0 * 600.0 / NOISE_P), r1, r2, std::abs(c.w0()));
    check(r1 <= 1.5, "nulled within 4000 samples (residual <= 1.5 dB)");
    check(r2 <= 1.5 && r2 <= r1 + 0.5, "no growth afterwards");
}

static void scen_clean() {
    Core c; Src s;
    c.gamma = (ap_uint<32>)((1u << 17) * 32.0 * NOISE_P / 2.0 > 4.0e9 ? 4.0e9 : (1u << 17) * 32.0 * NOISE_P / 2.0);
    const int N = 30000;
    double po = 0.0, pi = 0.0;
    for (int n = 0; n < N; n++) {
        int a, b, d, e; s.next(a, b, d, e);
        cd y = c.step(a, b, d, e);
        if (n >= 10000) { po += std::norm(y); pi += (double)a * a + (double)b * b; }
    }
    double d = db(po / pi);
    printf("  output / RX1 power %.2f dB\n", d);
    check(std::fabs(d) <= 1.0, "noise only: output within 1 dB of RX1");
}

static void scen_bypass() {
    {
        Core c; Src s; s.a = 600.0; c.cfg = PL_NPI_MODE_BYPASS;
        std::vector<int> h1r, h1i;
        bool same = true, wz = true;
        for (int n = 0; n < 5000; n++) {
            int a, b, d, e; s.next(a, b, d, e);
            h1r.push_back(a); h1i.push_back(b);
            cd y = c.step(a, b, d, e);
            if (n >= PL_NPI_LATENCY &&
                (y.real() != h1r[n - PL_NPI_LATENCY] || y.imag() != h1i[n - PL_NPI_LATENCY])) same = false;
            if (!c.w_zero()) wz = false;
        }
        check(same, "BYPASS with a jammer: output == RX1 (latency 3)");
        check(wz, "BYPASS: weights 0");
    }
}

static void scen_auto_quiet() {
    {
        Core c; Src s; c.cfg = PL_NPI_MODE_AUTO; c.det_thr = (ap_uint<32>)(4.0 * NOISE_P); c.det_hold = 1000;
        std::vector<int> h1r, h1i;
        bool same = true, det = false;
        for (int n = 0; n < 20000; n++) {
            int a, b, d, e; s.next(a, b, d, e);
            h1r.push_back(a); h1i.push_back(b);
            cd y = c.step(a, b, d, e);
            if (n >= PL_NPI_LATENCY &&
                (y.real() != h1r[n - PL_NPI_LATENCY] || y.imag() != h1i[n - PL_NPI_LATENCY])) same = false;
            if (c.st & PL_NPI_ST_DET) det = true;
        }
        check(same, "AUTO, noise only: output == RX1");
        check(!det, "AUTO, noise only: detector never on");
        check((c.st & PL_NPI_ST_STAP) != 0 && ((c.st >> PL_NPI_ST_NOTCH_LSB) & 7) == 0 &&
              !(c.st & PL_NPI_ST_DCBLK), "status: space-time core, 0 notches, no DC blocker");
    }
}

static void scen_gated() {
    Core c; Src s; c.cfg = PL_NPI_MODE_AUTO;
    c.det_thr = (ap_uint<32>)(4.0 * NOISE_P); c.det_hold = 2000;
    const int N = 60000, ON = 5000, OFF = 40000;
    std::vector<double> p(N);
    std::vector<int> h1r(N), h1i(N);
    int t_det = -1, t_byp = -1;
    bool tail_ok = true;
    for (int n = 0; n < N; n++) {
        s.a = (n >= ON && n < OFF) ? 600.0 : 0.0;
        int a, b, d, e; s.next(a, b, d, e);
        h1r[n] = a; h1i[n] = b;
        cd y = c.step(a, b, d, e);
        p[n] = std::norm(y);
        if (t_det < 0 && n >= ON && (c.st & PL_NPI_ST_ACTIVE)) t_det = n;
        if (n > OFF && t_byp < 0 && !(c.st & PL_NPI_ST_ACTIVE)) t_byp = n;
        if (t_byp > 0 && n > t_byp + PL_NPI_LATENCY + 1) {
            if (y.real() != h1r[n - PL_NPI_LATENCY] || y.imag() != h1i[n - PL_NPI_LATENCY] || !c.w_zero())
                tail_ok = false;
        }
    }
    double r = residual_db(p, 15000, 40000);
    unsigned cnt = (unsigned)(c.st >> PL_NPI_ST_CNT_LSB);
    printf("  detector on after %d samples, residual %.2f dB, bypass again %d samples after the jammer, %u events\n",
           t_det - ON, r, t_byp - OFF, cnt);
    check(t_det >= ON && t_det - ON <= 100, "detector on within 100 samples");
    check(r <= 1.5, "residual <= 1.5 dB once converged");
    check(t_byp > 0 && tail_ok, "back to bypass after the hold: output == RX1, weights 0");
    check(cnt == 1, "exactly one detector event");
}

// Band-limited Gaussian jammer: white noise through a 63-tap windowed-sinc
// low-pass (cut-off 0.4 fs, i.e. 80 % of the complex band).
static std::vector<cd> wideband(int n, double rms) {
    const int L = 63;
    std::vector<double> h(L);
    double sum = 0.0;
    for (int k = 0; k < L; k++) {
        double m = k - (L - 1) / 2.0, fc = 0.4;
        double sinc = (m == 0.0) ? 2.0 * fc : std::sin(2.0 * M_PI * fc * m) / (M_PI * m);
        h[k] = sinc * (0.54 - 0.46 * std::cos(2.0 * M_PI * k / (L - 1)));
        sum += h[k] * h[k];
    }
    std::vector<cd> w(n + L), j(n);
    for (auto &v : w) v = cd(grand(), grand()) / std::sqrt(2.0);
    for (int i = 0; i < n; i++) {
        cd a = 0.0;
        for (int k = 0; k < L; k++) a += h[k] * w[i + k];
        j[i] = a * rms / std::sqrt(sum);
    }
    return j;
}

// Residual (dB above the RX1 noise) of the least-squares weights for the
// regressor [x2(n), x1(n-1), x2(n-1), ...] (first nw of them), on the samples
// the core sees (noise included: large weights also amplify RX2's noise).
// Normal equations, complex Gaussian elimination.
static double ls_residual_db(const std::vector<cd> &j1, const std::vector<cd> &j2, int nw) {
    const int N = (int)j1.size();
    std::vector<std::vector<cd> > A(nw, std::vector<cd>(nw + 1, 0.0));
    std::vector<cd> u(nw);
    auto reg = [&](int n) {
        for (int i = 0; i < nw; i++) {
            int k = (i + 1) / 2;                       // delay
            u[i] = (i % 2 == 0) ? j2[n - k] : j1[n - k];
        }
    };
    for (int n = 3; n < N; n++) {
        reg(n);
        for (int r = 0; r < nw; r++) {
            for (int c2 = 0; c2 < nw; c2++) A[r][c2] += std::conj(u[r]) * u[c2];
            A[r][nw] -= std::conj(u[r]) * j1[n];
        }
    }
    for (int c2 = 0; c2 < nw; c2++) {
        int piv = c2;
        for (int r = c2 + 1; r < nw; r++) if (std::abs(A[r][c2]) > std::abs(A[piv][c2])) piv = r;
        std::swap(A[c2], A[piv]);
        for (int r = 0; r < nw; r++) {
            if (r == c2) continue;
            cd f = A[r][c2] / A[c2][c2];
            for (int k = c2; k <= nw; k++) A[r][k] -= f * A[c2][k];
        }
    }
    std::vector<cd> w(nw);
    for (int r = 0; r < nw; r++) w[r] = A[r][nw] / A[r][r];
    double e = 0.0;
    for (int n = 3; n < N; n++) {
        reg(n);
        cd y = j1[n];
        for (int i = 0; i < nw; i++) y += w[i] * u[i];
        e += std::norm(y);
    }
    return db(e / (N - 3) / NOISE_P);
}

static void scen_wideband() {
    const int N = 80000, L = 9;
    const double rms = std::sqrt(NOISE_P * 1000.0);          // J/N 30 dB
    std::vector<cd> j = wideband(N + L, rms);
    // RX2 path: fractional delay 0.35 samples (windowed sinc) and a tilt
    // (1 + 0.15 z^-1), times H.
    double fd[L], tsum = 0.0;
    for (int k = 0; k < L; k++) {
        double m = k - (L - 1) / 2.0 - 0.35;
        fd[k] = (std::sin(M_PI * m) / (M_PI * m)) * (0.54 - 0.46 * std::cos(2.0 * M_PI * (k + 0.5 - 0.35) / L));
        tsum += fd[k];
    }
    std::vector<cd> j1(N), j2(N);
    for (int n = 0; n < N; n++) {
        j1[n] = j[n + (L - 1) / 2 + 1];
        cd a = 0.0, b = 0.0;
        for (int k = 0; k < L; k++) a += fd[k] / tsum * j[n + 1 + L - 1 - k];
        for (int k = 0; k < L; k++) b += fd[k] / tsum * j[n + L - 1 - k];
        j2[n] = H * (a + 0.15 * b);
    }
    std::vector<cd> x1(N), x2(N);
    for (int n = 0; n < N; n++) {
        x1[n] = cd(q16(j1[n].real() + unoise(20)), q16(j1[n].imag() + unoise(20)));
        x2[n] = cd(q16(j2[n].real() + unoise(20)), q16(j2[n].imag() + unoise(20)));
    }
    // least-squares optimum for one spatial weight on x2(n), and for the
    // core's 7 space-time weights
    const double single = ls_residual_db(x1, x2, 1);
    const double stap   = ls_residual_db(x1, x2, PL_NPI_NW);

    Core c;
    std::vector<double> p(N);
    for (int n = 0; n < N; n++)
        p[n] = std::norm(c.step((int)x1[n].real(), (int)x1[n].imag(), (int)x2[n].real(), (int)x2[n].imag()));
    double r = residual_db(p, 40000, N);
    if (getenv("PL_NPI_TRACE"))
        for (int b = 0; b < N; b += 10000) printf("    %5d-%5d: %.2f dB\n", b, b + 10000, residual_db(p, b, b + 10000));
    printf("  wideband jammer %.1f dB above the noise: residual %.2f dB (4-tap space-time core);\n"
           "  least-squares optimum %.2f dB with the 7 space-time weights, %.2f dB with one spatial weight\n",
           db(rms * rms / NOISE_P), r, stap, single);
    check(r <= stap + 1.5, "core within 1.5 dB of the space-time optimum");
    check(r <= single - 6.0, "at least 6 dB better than one spatial weight could be");
}

static void scen_hold() {
    Core c; Src s; s.a = 600.0;
    for (int n = 0; n < 10000; n++) { int a, b, d, e; s.next(a, b, d, e); c.step(a, b, d, e); }
    c.cfg = PL_NPI_MODE_HOLD;
    for (int n = 0; n < 20; n++) { int a, b, d, e; s.next(a, b, d, e); c.step(a, b, d, e); }  // drain the pipeline
    ap_uint<192> w0 = c.w;
    bool same = true;
    std::vector<double> p(10000);
    for (int n = 0; n < 10000; n++) {
        int a, b, d, e; s.next(a, b, d, e);
        p[n] = std::norm(c.step(a, b, d, e));
        if (c.w != w0) same = false;
    }
    double r = residual_db(p, 0, 10000);
    printf("  residual in HOLD %.2f dB\n", r);
    check(same, "HOLD: weights frozen");
    check(r <= 1.5, "HOLD: the null holds");
    check(!(c.st & PL_NPI_ST_ADAPT) && (c.st & PL_NPI_ST_ACTIVE), "HOLD status: active, not adapting");
}

static void scen_shift() {
    // One core (the core is static: one per process). Noise only, ON: the
    // shift only scales the output, not the sum the weights adapt on, so the
    // output power with shift 2 must be 12 dB above that with shift 0.
    Core c; Src s;
    double p0 = 0.0, p2 = 0.0;
    for (int n = 0; n < 40000; n++) {
        if (n == 20000) c.cfg = PL_NPI_MODE_ON | (2u << PL_NPI_CFG_SH_LSB);
        int x1r, x1i, x2r, x2i; s.next(x1r, x1i, x2r, x2i);
        cd y = c.step(x1r, x1i, x2r, x2i);
        if (n >= 5000 && n < 20000) p0 += std::norm(y);
        if (n >= 25000)             p2 += std::norm(y);
    }
    double g = db((p2 / 15000.0) / (p0 / 15000.0));
    printf("  make-up shift 2: %+.2f dB\n", g);
    check(std::fabs(g - 12.04) <= 0.5, "shift 2 = +12 dB while filtering");
    c.cfg = PL_NPI_MODE_BYPASS | (2u << PL_NPI_CFG_SH_LSB);
    std::vector<int> h1r, h1i;
    bool same = true;
    for (int n = 0; n < 2000; n++) {
        int x1r, x1i, x2r, x2i; s.next(x1r, x1i, x2r, x2i);
        h1r.push_back(x1r); h1i.push_back(x1i);
        cd y = c.step(x1r, x1i, x2r, x2i);
        if (n >= PL_NPI_LATENCY && (y.real() != h1r[n - PL_NPI_LATENCY] || y.imag() != h1i[n - PL_NPI_LATENCY])) same = false;
    }
    check(same, "shift ignored in bypass");
}

int main(int argc, char **argv) {
    int scen = (argc > 1) ? atoi(argv[1]) : 1;
    printf("PL_NPI_CSIM: scenario %d (space-time %d x %d taps)\n", scen, PL_NPI_ANT, PL_NPI_TAPS);
    switch (scen) {
    case 1: scen_cw(); break;
    case 2: scen_clean(); break;
    case 3: scen_bypass(); break;
    case 4: scen_gated(); break;
    case 5: scen_wideband(); break;
    case 6: scen_hold(); break;
    case 7: scen_shift(); break;
    case 8: scen_auto_quiet(); break;
    default: printf("unknown scenario %d\n", scen); return 2;
    }
    if (fails) { printf("PL_NPI_CSIM: FAIL (%d)\n", fails); return 1; }
    printf("PL_NPI_CSIM: PASS\n");
    return 0;
}
