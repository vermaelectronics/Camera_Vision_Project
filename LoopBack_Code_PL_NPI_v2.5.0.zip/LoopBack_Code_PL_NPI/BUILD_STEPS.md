# Build PL-NPI v2.4 step by step (zip → BOOT.BIN → SD card)

v2.4 changes the HLS core (IP 2.1), the passthrough (VERSION 2.4) and the
block design, so **every stage from 3 to 9 must run**. What changed and why:
`README_PL_NPI_v2.4.md`. Host-only checks, without Xilinx tools:
`Tests/run_regression.sh` (§7).

Every command below is meant to be typed in a Linux terminal (Ubuntu 22.04 or
20.04) on the PC that has the Xilinx tools. Wait for each step to pass before
going to the next one. Each step prints a check line at the end.

---

## 0. What you need (once)

| Item | Value |
|---|---|
| OS | Ubuntu 22.04 (20.04 also works) |
| Tools | **Vivado, Vitis and Vitis HLS 2023.2**, installed under `/tools/Xilinx` or `/opt/Xilinx`. The xc7z020 is covered by the free licence. |
| Disk / RAM | ~40 GB free, 16 GB RAM (8 GB works with `--jobs 4`) |
| Packages | `sudo apt install unzip make gcc g++ git` |

Check that the tools are there:

```bash
ls /tools/Xilinx/Vivado/2023.2/settings64.sh /tools/Xilinx/Vitis/2023.2/settings64.sh /tools/Xilinx/Vitis_HLS/2023.2/settings64.sh
```

(If they are in `/opt/Xilinx`, use that path in all the commands.)

---

## 1. Unzip into a NEW folder

```bash
mkdir -p ~/pl_npi_v24
cd ~/pl_npi_v24
unzip ~/Downloads/LoopBack_Code_PL_NPI_v2.4.0.zip
cd LoopBack_Code_PL_NPI
chmod +x Automation/Linux/*.sh Automation/Linux/steps/*.sh
```

Do **not** unzip over the v2.3 folder: an old `Build/ip_repo/pl_npi` (version
2.0, no notch port) must not be reused. The block design refuses it anyway.

---

## 2. Load the tools (every new terminal)

```bash
source /tools/Xilinx/Vivado/2023.2/settings64.sh
source /tools/Xilinx/Vitis/2023.2/settings64.sh
source /tools/Xilinx/Vitis_HLS/2023.2/settings64.sh
vivado -version | head -1        # must say v2023.2
which vitis_hls xsct bootgen      # all three must be found
```

---

## 3. Build, one step at a time

Run these from the `LoopBack_Code_PL_NPI` folder. The times are typical for
a 16-thread PC.

### Step 1: copy the ADI library (seconds)

```bash
./Automation/Linux/steps/01_vendor.sh
```
Check: `STEP 1 vendor: PASS`

### Step 2: package the ADI library IP (5–10 min)

```bash
./Automation/Linux/steps/02_libip.sh
```
Check: `STEP 2 libip: PASS (11 library logs ...)`

### Step 3: the PL-NPI core in Vitis HLS (5–15 min)

```bash
./Automation/Linux/steps/03_npi.sh
```
Check, all of these in the output:
```
PL_NPI_CSIM: PASS (scenario 1)   ... 2 3 4 5 7 8 9 10 11 12 (11 lines)
PL_NPI_HLS: estimated clock period X ns (target 10 ns), achieved II 1 (requested 1)
PL_NPI_HLS: IP antsdr:gnss:pl_npi:2.1 -> .../Build/ip_repo/pl_npi
PL_NPI_HLS: PASS
```
**This is the step to watch in v2.4.** The two CW notches are new
recursive loops at II=1 on a 10 ns clock, and they have **not** been
synthesised yet. If the clock estimate is above 10 ns and the critical path
names `ns_re`/`ns_im`/`nm_*` (the notch state), rebuild with one notch or
none. Then continue with step 4 as usual:
```bash
PL_NPI_NOTCHES=1 ./Automation/Linux/steps/03_npi.sh     # or PL_NPI_NOTCHES=0
```
If it fails anywhere else, send me the `PL_NPI_HLS` lines and the critical path:
```bash
grep -E "PL_NPI_HLS|Pipelining result|Estimated Fmax" Build/Logs/npi.log
grep -A14 "HLS 200-1016" Build/Logs/npi.log
```
To see one scenario's numbers: `grep -B1 -A4 "scenario 7" Build/Logs/npi.log`

### Step 4: package gnss_passthrough (1–2 min)

```bash
./Automation/Linux/steps/04_ip.sh
```
Check: `IP_PACKAGE_OK`

### Step 5: create the Vivado project (2–5 min)

```bash
./Automation/Linux/steps/05_project.sh
```
Check: `CREATE_RESULT: PASS`
(`GNSS-CRPA: PL-NPI IP resolved in catalog: antsdr:gnss:pl_npi:2.1` is
printed in `Build/Logs/project.log`.)

### Step 6: synthesis, implementation, bitstream (20–60 min)

```bash
./Automation/Linux/steps/06_build.sh
```
Check:
```
BUILD_TIMING: MET
BUILD_RESULT: PASS
Build/Output/system_top.bit   Build/Output/system.xsa   (listed)
```
If it says `BUILD_TIMING: VIOLATED` with failing paths on `rx_clk`: open
`Source/XDC/system.xdc` and change `-period  4` to `-period  5` on the
`rx_clk` line. Then run steps 5 and 6 again. The default profile
(`gnss_band=4`, 50 MS/s) still works at 5 ns. `gnss_band=1` (61.44 MS/s,
the only profile with GLONASS) does not.

### Step 7: the application ELF (2–5 min)

Choose ONE:

```bash
# (a) bench / console build: TX1 silent at power-on, you type gnss_tx=1
./Automation/Linux/steps/07_sw.sh

# (b) unattended SD-card build: TX1 starts BY ITSELF at power-on (70 dB attenuation)
#     CONDUCTED, ATTENUATED COAX ONLY. Read SD_Image/README_SD_CARD.md first.
./Automation/Linux/steps/07_sw.sh --defines GNSS_DEPLOY_AUTO_TX
```
Check: `SW_RESULT: PASS`

Options you can add to `--defines` (comma-separated):

| Define | Effect |
|---|---|
| `GNSS_DEPLOY_AUTO_TX` | TX1 on at power-on (the shortest time to fix: no typing) |
| `GNSS_TX_START_ATTEN_MDB=65000` | level `gnss_tx=1` starts at (default 70000 = 70 dB; bigger = quieter) |
| `GNSS_DEPLOY_TX_ATTEN_MDB=65000` | level of the auto-start build (default 70000) |
| `GNSS_BOOT_DIAG` | brings back the boot I/Q captures and band probe (adds ~1.5 s) |

Example: `./Automation/Linux/steps/07_sw.sh --defines GNSS_DEPLOY_AUTO_TX,GNSS_DEPLOY_TX_ATTEN_MDB=65000`

### Step 8: the FSBL (1–3 min)

```bash
./Automation/Linux/steps/08_fsbl.sh
```
Check: `FSBL_RESULT: PASS`

### Step 9: BOOT.BIN (seconds)

```bash
./Automation/Linux/steps/09_boot.sh
```
Check: `Build/Output/BOOT.BIN` is listed, with its size. Note the sha256 that
`Build/Logs/boot.log` prints.

### Step 10: one-page report (optional)

```bash
./Automation/Linux/steps/10_report.sh
```
It prints a pass/fail line per stage, the HLS clock/II and the timing. Paste
it into your next message if anything failed.

---

## 4. All in one go (same result)

```bash
./Automation/Linux/build_all.sh --jobs 16                                  # bench build
./Automation/Linux/build_all.sh --jobs 16 --defines GNSS_DEPLOY_AUTO_TX    # SD-card build
```

Only the firmware changed (e.g. a different `--defines`)? Then:

```bash
./Automation/Linux/build_all.sh --from sw --to boot --defines GNSS_DEPLOY_AUTO_TX
```

---

## 5. SD card

1. Format the card as **FAT32**.
2. Copy **`Build/Output/BOOT.BIN`** to the **root** of the card. Do not use
   `SD_Image/BOOT.BIN`: that is an old image without PL-NPI v2.4.
3. Set the board's **BOOT switch to SD**, insert the card, connect RF:

| Port | Connect |
|---|---|
| RX1, RX2 | the two antennas (same antenna type and same cable length on both) |
| TX1 | GNSS receiver, conducted coax with attenuation |
| USB (console) | PC, PuTTY at 115200 8N1 (see `TESTING_PUTTY.md`) |

4. Power on. The console must show (among other lines):

```
gnss_pt: present at 0x43c00000, version 2.4
SELFTEST: PASS - ...
ANTI-JAM (PL-NPI 2.4.0): ON, bypassed until a jammer appears.
```

If it says `version 2.3` or older, the card has an old BOOT.BIN (the
anti-jam still runs, but without the DC blocker and the notches).

Then type `gnss_band?`. It must show `4 = USER`, LO 1570.250 MHz, 50 MS/s,
50 MHz, and the AD9361 FIRs `off`. GPS, Galileo/B1C and BeiDou B1I say
`OK`; the two GLONASS lines say `OUTSIDE: not received` (use `gnss_band=1` for
GLONASS). Then type `gnss_report`: the first line is `JAMMER STATUS: OFF`
with no jammer connected.

---

## 6. If a step fails

```bash
tail -50 Build/Logs/<stage>.log        # stage = npi, ip, project, build, sw, fsbl, boot
./Automation/Linux/steps/10_report.sh
```

Re-run the same step after fixing. Steps 1–4 can be repeated safely. Step 5
deletes and recreates the Vivado project.

Send me: the failing step, the last 50 lines of its log and the
`10_report.sh` output.

---

## 7. Host regression (no Xilinx tools needed, about 2 min)

```bash
sudo apt install gcc g++ iverilog
# ap_int headers: either source Vitis HLS settings64.sh (sets $XILINX_HLS), or
git clone https://github.com/Xilinx/HLS_arbitrary_Precision_Types ~/hls_apt
HLS_INCLUDE=~/hls_apt/include Tests/run_regression.sh --full
```
Check: `REGRESSION: PASS (0 skipped)`. `--full` also prints the GPS C/N0
table for CW J/S 10/15/30/40 dB. Logs are in `Build/Tests/`.
