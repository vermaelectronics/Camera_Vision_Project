/******************************************************************************
 *  gnss_passthrough.h
 *  Driver for the project's custom FPGA processing block.
 *
 *  Original work for the ANTSDR E310 V1 GNSS CRPA project.  Not derived from
 *  Analog Devices or MicroPhase source.
 *
 *  The register map here MUST stay in step with:
 *    Source/HDL/gnss_passthrough.v          (the hardware)
 *    Source/Config/board_e310_v1.json       (the shared description)
 *  Change one, change all three.
 *****************************************************************************/
#ifndef GNSS_PASSTHROUGH_H_
#define GNSS_PASSTHROUGH_H_

#include <stdint.h>

/* --------------------------------------------------------------------------
 * Base address.
 *
 * Prefer the value Vitis generates from the block design.  Fall back to the
 * address this project assigns in board_e310_v1.json only if xparameters.h
 * does not define it -- and say so loudly at compile time, because a silent
 * fallback would be exactly the kind of guess requirement 32 forbids.
 * -------------------------------------------------------------------------- */
/* app_config.h FIRST. It is what defines XILINX_PLATFORM, and without it the
 * guard below is false, xparameters.h is never included, and the fallback
 * silently wins -- which is precisely what the comment above forbids.
 *
 * That is not hypothetical: every build from 2026-09-11 to 2026-09-14 emitted
 * the #warning below and used the hard-coded address. gnss_passthrough.c
 * includes this header first and nothing had pulled in app_config.h yet, and
 * the -DXILINX_PLATFORM in build_software.py's USER_COMPILE_FLAGS was not
 * reaching the compile line. The address happened to be correct, so nothing
 * broke -- the check was simply not doing its job.
 *
 * app_config.h has its own include guard, so including it here is harmless. */
#include "app_config.h"

#ifdef XILINX_PLATFORM
#include <xparameters.h>
#endif

#if defined(XPAR_GNSS_PASSTHROUGH_0_BASEADDR)
#define GNSS_PT_BASEADDR   XPAR_GNSS_PASSTHROUGH_0_BASEADDR
#elif defined(XPAR_GNSS_PASSTHROUGH_BASEADDR)
#define GNSS_PT_BASEADDR   XPAR_GNSS_PASSTHROUGH_BASEADDR
#elif defined(XPAR_GNSS_PASSTHROUGH_S_AXI_BASEADDR)
/* Classic (non-SDT) BSP naming, e.g. Vitis 2023.2 XSCT flow. */
#define GNSS_PT_BASEADDR   XPAR_GNSS_PASSTHROUGH_S_AXI_BASEADDR
#else
#warning "gnss_passthrough base address not found in xparameters.h; using the project-assigned 0x43C00000. Verify this against the generated XSA before trusting any register read."
#define GNSS_PT_BASEADDR   0x43C00000U
#endif

/* ---- register offsets ---------------------------------------------------- */
#define GNSS_PT_REG_ID              0x00U   /* RO  0x47435031 "GCP1"          */
#define GNSS_PT_REG_VERSION         0x04U   /* RO  {major,minor}              */
#define GNSS_PT_REG_SCRATCH         0x08U   /* RW                             */
#define GNSS_PT_REG_CONTROL         0x0CU   /* RW                             */
#define GNSS_PT_REG_STATUS          0x10U   /* RO                             */
#define GNSS_PT_REG_RX_COUNT_CH0    0x14U   /* RO                             */
#define GNSS_PT_REG_TX_COUNT_CH0    0x18U   /* RO                             */
#define GNSS_PT_REG_OVERFLOW_COUNT  0x1CU   /* RO                             */
#define GNSS_PT_REG_UNDERFLOW_COUNT 0x20U   /* RO                             */
#define GNSS_PT_REG_RX_SNAPSHOT_CH0 0x24U   /* RO  {Q[31:16], I[15:0]}        */
#define GNSS_PT_REG_TX_SNAPSHOT_CH0 0x28U   /* RO  {Q[31:16], I[15:0]}        */
#define GNSS_PT_REG_FIFO_LEVEL      0x2CU   /* RO  [5:0] ch0, [13:8] ch1      */
#define GNSS_PT_REG_RX_COUNT_CH1    0x30U   /* RO                             */
#define GNSS_PT_REG_TX_COUNT_CH1    0x34U   /* RO                             */
#define GNSS_PT_REG_RX_SNAPSHOT_CH1 0x38U   /* RO                             */
#define GNSS_PT_REG_CRPA_COEF(n)    (0x40U + ((n) * 4U))  /* RW, n = 0..15    */
/* SMI-PI v4 space-time weights (see gnss_aj_math.h for the layout).
 * AJ_W, AJ_CFG, AJ_NORM and AJ_WC are SHADOW copies; a write to AJ_COMMIT
 * hands all of them to the filter in one clock. AJ_COMMIT reads back a commit
 * counter. */
#define GNSS_PT_REG_AJ_W(k)         (0x400U + ((k) * 4U)) /* RW, k = 0..63 (4.9: 32 taps per channel) */
#define GNSS_PT_REG_AJ_COMMIT       0x180U  /* W: commit, R: count            */
#define GNSS_PT_REG_AJ_INFO         0x184U  /* RO 0x10040C06                  */
#define GNSS_PT_REG_AJ_CFG          0x188U  /* RW [0] bypass, [10:8] shift, [14:12] weight scale */
#define GNSS_PT_REG_AJ_NORM         0x18CU  /* RW g2, Q3.13 {im, re}          */
#define GNSS_PT_REG_AJ_WC(k)        (0x190U + ((k) * 4U)) /* RW image taps 0,1 */
#define GNSS_PT_REG_AJ_CFG_ACTIVE   0x198U  /* RO AJ_CFG as committed         */
/* bitstream 4.6 (AJ_INFO layout 5): pulse blanker on the filter output, RX peak hold */
#define GNSS_PT_REG_AJ_BLK_THR      0x19CU  /* RW shadow: blanker threshold (sum of 8 samples of I^2+Q^2), committed by AJ_COMMIT */
#define GNSS_PT_REG_AJ_BLK_THR_ACT  0x1A0U  /* RO committed threshold         */
#define GNSS_PT_REG_AJ_BLK_COUNT    0x1A4U  /* RO samples blanked since the counter clear */
#define GNSS_PT_REG_AJ_BLK_BURSTS   0x1A8U  /* RO bursts blanked since the counter clear  */
#define GNSS_PT_REG_AJ_RX_PEAK      0x1ACU  /* RO [15:0] largest |I|,|Q| of RX1/RX2 in the last window, [31:16] window counter */
#define GNSS_PT_AJ_INFO_EXPECTED    0x06030C07U   /* 4.9.14 6x6: 6 taps per channel, reference delay 3 */   /* layout 6 = v4.7 (reference delay 4); 5 = v4.6 (pulse blanker, peak hold); 4 = v4.5 */
#define GNSS_PT_AJ_LAYOUT_BLANK     5U            /* first layout with the blanker and the peak hold */
#define GNSS_PT_AJ_CFG_BLANK        0x8000U       /* AJ_CFG[15]: blanker enable (layout 5) */
#define GNSS_PT_BLK_THR_OFF         0xFFFFFFFFU   /* threshold that never triggers */
#define GNSS_PT_AJ_CFG_BYPASS       0x1U
#define GNSS_PT_AJ_CFG_SHIFT(s)     ((uint32_t)((s) & 7) << 8)
#define GNSS_PT_AJ_CFG_WS(w)        ((uint32_t)((w) & 7) << 12)   /* weight scale: words hold w * 2^ws (4.4) */

/* ---- expected identity --------------------------------------------------- */
#define GNSS_PT_EXPECTED_ID         0x47435031U
/* 1.0 = Phase-1 identity passthrough.
 * 1.1 = adds the RX->TX sample alignment stage (RX is right-aligned 12-in-16,
 *       the AD9361 DAC consumes [15:4]). A board reporting 1.0 is running a
 *       bitstream whose TX output is 24 dB low with 4 bits discarded. */
/* 2.x = PL-NPI builds (LoopBack_Code_PL_NPI).
 * 3.0 = SMI-PI build: closed-form power inversion y = x1 - a*x2 in a separate
 *       block-design IP (smi_pi_0, CONTROL[5], loading L in 0x48, weight band
 *       in STATUS[21:20]). No PI-NLMS or PL-NPI core.
 * 4.0 = SMI-PI space-time build: 16+16-tap filter (smi_pi_0 v2.0) whose 32
 *       weights the ARM computes and writes to AJ_W / AJ_COMMIT. No 0x48
 *       loading, no weight band.
 * 4.1 = adds AJ_CFG (bypass, output make-up shift), AJ_NORM (RX2 input
 *       normalisation) and the image taps AJ_WC (smi_pi_0 v2.1).
 * 4.9.14 = TX2 (ch1 DAC) carries a copy of the CRPA output instead of raw
 *       RX2, and is MUTED unless CONTROL[4] tx2_on = 1. CONTROL[3] is now
 *       ch1_raw (1 = raw RX2, diagnostics); up to 4.9.13 it was ch1_copy with
 *       the opposite sense. */
#define GNSS_PT_EXPECTED_VERSION    0x0004090EU
#define GNSS_PT_VERSION_TX2_MUTE    0x0004090EU   /* first bitstream with CONTROL[4] tx2_on */

/* ---- CONTROL bits -------------------------------------------------------- */
#define GNSS_PT_CTRL_PASS_EN        (1U << 0)  /* 1 = RX->TX passthrough      */
#define GNSS_PT_CTRL_MUTE           (1U << 1)  /* 1 = drive zeros to the DAC  */
#define GNSS_PT_CTRL_SWAP_IQ        (1U << 2)
#define GNSS_PT_CTRL_CH1_RAW        (1U << 3)  /* 4.9.14: 1 = TX2 = raw RX2; 0 = TX2 = CRPA output (default) */
#define GNSS_PT_CTRL_CH1_COPY_OLD   (1U << 3)  /* up to 4.9.13: 1 = TX2 fed from ch0 (same bit, opposite sense) */
#define GNSS_PT_CTRL_TX2_ON         (1U << 4)  /* 4.9.14: 1 = TX2 live; 0 = TX2 forced to zero (default) */
#define GNSS_PT_CTRL_SMI_EN         (1U << 5)  /* ch0 TX = SMI-PI(RX1, RX2)   */
#define GNSS_PT_CTRL_CNT_CLEAR      (1U << 8)  /* held, not self-clearing     */

/* ---- STATUS bits --------------------------------------------------------- */
#define GNSS_PT_ST_ADC_EN_I0        (1U << 0)
#define GNSS_PT_ST_ADC_EN_Q0        (1U << 1)
#define GNSS_PT_ST_DAC_EN_I0        (1U << 2)
#define GNSS_PT_ST_DAC_EN_Q0        (1U << 3)
#define GNSS_PT_ST_FIFO0_EMPTY      (1U << 4)
#define GNSS_PT_ST_FIFO0_FULL       (1U << 5)
#define GNSS_PT_ST_FIFO1_EMPTY      (1U << 6)
#define GNSS_PT_ST_FIFO1_FULL       (1U << 7)
#define GNSS_PT_ST_OVERFLOW         (1U << 8)
#define GNSS_PT_ST_UNDERFLOW        (1U << 9)
#define GNSS_PT_ST_SMI_DROP         (1U << 10) /* pair lost at smi_pi_0      */
#define GNSS_PT_ST_PASS_EN_SYNCED   (1U << 16)
#define GNSS_PT_ST_SMI_EN_SYNCED    (1U << 18)

/* ---- return codes -------------------------------------------------------- */
#define GNSS_PT_OK                   0
#define GNSS_PT_ERR_ID              -1   /* core not present / wrong ID       */
#define GNSS_PT_ERR_NO_RX           -2   /* no RX samples arriving            */
#define GNSS_PT_ERR_NO_TX           -3   /* no TX requests arriving           */
#define GNSS_PT_ERR_SCRATCH         -4   /* register read/write failed        */
#define GNSS_PT_ERR_ALIGNMENT       -5   /* TX samples are not left-aligned   */

/* ---- API ----------------------------------------------------------------- */

uint32_t gnss_pt_read (uint32_t offset);
void     gnss_pt_write(uint32_t offset, uint32_t value);

/* Verifies the core responds with the expected ID and that SCRATCH holds a
 * written value.  Call before anything else. */
int32_t  gnss_pt_probe(void);

/* Enable or disable RX->TX passthrough.  Disabled restores the untouched
 * vendor behaviour, where the DAC is driven by the DMA/DDS path. */
void     gnss_pt_set_passthrough(int enable);
void     gnss_pt_set_mute(int mute);
void     gnss_pt_clear_counters(void);

/* SMI-PI space-time filter (bitstream v4.x). Enabled, channel 0 TX carries
 * the filter output (RX1 and RX2 combined) instead of RX1 alone; passthrough
 * must also be on. The weights are whatever was last committed. */
void     gnss_pt_set_smi(int enable);
/* 4.9.14: TX2 (ch1 DAC). Its source is always the CRPA output -- the same
 * samples TX1 carries -- never raw RX2. on = 0 mutes it (digital zero, the
 * default at power-on and boot), on = 1 lets the copy out. The attenuation
 * stays at GNSS_L1_TX2_ATTEN_MDB either way. On a bitstream older than
 * 4.9.14 TX2 cannot be muted: the copy is selected and a warning printed.
 * gnss_pt_tx2_on() reads back whether TX2 is live. */
void     gnss_pt_set_tx2(int on);
int      gnss_pt_tx2_on(void);
/* Writes the 34 weight words (32 space-time + 2 image, Q3.12, see
 * gnss_aj_math.h), cfg (GNSS_PT_AJ_CFG_*) and the RX2 normalisation g2
 * (Q3.13 real part; imaginary 0), and commits them in one go: the filter
 * never runs a half-written set. re/im may be NULL to keep the weights that
 * are in the shadow registers (bypass switching). */
void     gnss_pt_write_aj(const int16_t *re, const int16_t *im,
                          uint32_t cfg, int32_t g2_q13, uint32_t blk_thr);

/* Snapshot of everything worth observing at runtime (requirement 58). */
typedef struct {
    uint32_t id;
    uint32_t version;
    uint32_t control;
    uint32_t status;
    uint32_t rx_count_ch0;
    uint32_t tx_count_ch0;
    uint32_t rx_count_ch1;
    uint32_t tx_count_ch1;
    uint32_t overflow_count;
    uint32_t underflow_count;
    uint32_t fifo_level_ch0;
    uint32_t fifo_level_ch1;
    int16_t  rx_i0, rx_q0;
    int16_t  tx_i0, tx_q0;
    int      passthrough_enabled;
    int      overflow_sticky;
    int      underflow_sticky;
} gnss_pt_state_t;

void     gnss_pt_get_state(gnss_pt_state_t *st);
void     gnss_pt_print_state(void);

/* Confirms samples are actually moving through the block by sampling the
 * counters twice, separated by delay_ms (requirement 59).
 * Returns GNSS_PT_OK only if both RX and TX counters advanced, and -- when
 * passthrough is on and unmuted -- the TX snapshot is left-aligned. */
int32_t  gnss_pt_check_dataflow(uint32_t delay_ms);

#endif /* GNSS_PASSTHROUGH_H_ */
